import { createFileRoute } from "@tanstack/react-router";
import { PageLayout } from "@/components/site/PageLayout";
import { Testimonials, SectionHeading, StatsMarquee } from "@/components/site/Site";

export const Route = createFileRoute("/reviews")({
  head: () => ({
    meta: [
      { title: "ARTRIX SOFTWARE — Reviews & Testimonials" },
      { name: "description", content: "Real stories from 50,000+ traders profiting on autopilot with ARTRIX." },
    ],
    links: [{ rel: "canonical", href: "/reviews" }],
  }),
  component: ReviewsPage,
});

function ReviewsPage() {
  return (
    <PageLayout>
      <section className="relative pt-32 pb-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <SectionHeading
            eyebrow="Reviews · Testimonials"
            title="Lives Changed by ARTRIX"
            subtitle="Real profit stories from real traders across 180+ countries."
          />
        </div>
      </section>

      <StatsMarquee />
      <Testimonials />

      {/* CTA at bottom */}
      <div className="pb-20 text-center">
        <a
          href="/products"
          className="btn-primary btn-primary-pulse inline-flex items-center gap-2 rounded-2xl px-8 py-4 text-lg"
        >
          See Products <span style={{ fontSize: "1.2em" }}>→</span>
        </a>
      </div>
    </PageLayout>
  );
}
