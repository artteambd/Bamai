import { createFileRoute } from "@tanstack/react-router";
import { PageLayout } from "@/components/site/PageLayout";
import { Hero, StatsMarquee, Features, FinalCTA } from "@/components/site/Site";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ARTRIX SOFTWARE — Profit on Autopilot. A to Z." },
      { name: "description", content: "Elite AI trading bot empire. Neural AI, 0.01s execution, 24/7 autopilot. Join 50,000+ traders profiting on autopilot." },
      { property: "og:title", content: "ARTRIX SOFTWARE — Profit on Autopilot" },
      { property: "og:description", content: "From A to Z — the entire trading journey automated. You invest. AI does everything. You profit." },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: HomePage,
});

function HomePage() {
  return (
    <PageLayout>
      <Hero />
      <StatsMarquee />
      <Features />
      <FinalCTA />
    </PageLayout>
  );
}
