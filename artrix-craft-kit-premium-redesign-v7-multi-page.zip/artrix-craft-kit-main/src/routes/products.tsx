import { createFileRoute } from "@tanstack/react-router";
import { PageLayout } from "@/components/site/PageLayout";
import { Shop, SectionHeading } from "@/components/site/Site";
import { motion } from "framer-motion";
import { Package } from "lucide-react";

export const Route = createFileRoute("/products")({
  head: () => ({
    meta: [
      { title: "ARTRIX SOFTWARE — Products & Pricing" },
      { name: "description", content: "Choose your ARTRIX trading bot tier. Starter, Pro, Elite, and Institutional plans with Add to Cart functionality." },
    ],
    links: [{ rel: "canonical", href: "/products" }],
  }),
  component: ProductsPage,
});

function ProductsPage() {
  return (
    <PageLayout>
      {/* Page hero banner */}
      <section className="relative pt-32 pb-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <SectionHeading
            eyebrow="Products · Pricing"
            title="Choose Your Profit Engine"
            subtitle="A‑to‑Z trading bots for every ambition. Pick a tier, add to cart, and let the bots work."
          />
        </div>
      </section>

      {/* Full Shop section with pricing cards + Add to Cart + ROI Calculator */}
      <Shop />
    </PageLayout>
  );
}
