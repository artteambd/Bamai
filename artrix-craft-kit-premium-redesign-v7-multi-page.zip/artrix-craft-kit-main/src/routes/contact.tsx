import { createFileRoute } from "@tanstack/react-router";
import { PageLayout } from "@/components/site/PageLayout";
import { Contact, SectionHeading } from "@/components/site/Site";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "ARTRIX SOFTWARE — Contact Us" },
      { name: "description", content: "Talk to the ARTRIX team. Sales, support, partnerships — we respond within the hour." },
    ],
    links: [{ rel: "canonical", href: "/contact" }],
  }),
  component: ContactPage,
});

function ContactPage() {
  return (
    <PageLayout>
      <section className="relative pt-32 pb-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <SectionHeading
            eyebrow="Contact"
            title="Talk to the ARTRIX Team"
            subtitle="Sales, support, partnerships — we respond within the hour."
          />
        </div>
      </section>

      <Contact />
    </PageLayout>
  );
}
