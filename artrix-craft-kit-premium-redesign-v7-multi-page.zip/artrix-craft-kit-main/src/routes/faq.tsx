import { createFileRoute } from "@tanstack/react-router";
import { PageLayout } from "@/components/site/PageLayout";
import { About, Timeline, SectionHeading } from "@/components/site/Site";

export const Route = createFileRoute("/faq")({
  head: () => ({
    meta: [
      { title: "ARTRIX SOFTWARE — About & FAQ" },
      { name: "description", content: "Learn about the ARTRIX mission, our journey from garage to empire, and how we democratize institutional-grade trading." },
    ],
    links: [{ rel: "canonical", href: "/faq" }],
  }),
  component: FAQPage,
});

function FAQPage() {
  return (
    <PageLayout>
      <section className="relative pt-32 pb-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <SectionHeading
            eyebrow="About · Mission"
            title="The ARTRIX Story"
            subtitle="Founded by elite quant engineers. Built to democratize the trading edge the 1% kept to themselves."
          />
        </div>
      </section>

      <About />
      <Timeline />

      {/* CTA at bottom */}
      <div className="pb-20 text-center">
        <a
          href="/products"
          className="btn-primary btn-primary-pulse inline-flex items-center gap-2 rounded-2xl px-8 py-4 text-lg"
        >
          See Products <span style={{ fontSize: "1.2em" }}>→</span>
        </a>
      </div>
    </PageLayout>
  );
}
