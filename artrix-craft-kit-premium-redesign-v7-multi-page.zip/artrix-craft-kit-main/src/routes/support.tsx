import { createFileRoute } from "@tanstack/react-router";
import { PageLayout } from "@/components/site/PageLayout";
import { LiveDemo, SectionHeading } from "@/components/site/Site";

export const Route = createFileRoute("/support")({
  head: () => ({
    meta: [
      { title: "ARTRIX SOFTWARE — Support & Live Demo" },
      { name: "description", content: "Watch ARTRIX bots trade live. See the neural engine in action and get support from our team." },
    ],
    links: [{ rel: "canonical", href: "/support" }],
  }),
  component: SupportPage,
});

function SupportPage() {
  return (
    <PageLayout>
      <section className="relative pt-32 pb-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <SectionHeading
            eyebrow="Support · Live Demo"
            title="Watch the Bots Print"
            subtitle="A live simulation of ARTRIX in action. See the neural engine trade in real time."
          />
        </div>
      </section>

      <LiveDemo />

      {/* CTA at bottom */}
      <div className="pb-20 text-center">
        <a
          href="/contact"
          className="btn-primary btn-primary-pulse inline-flex items-center gap-2 rounded-2xl px-8 py-4 text-lg"
        >
          Contact Support <span style={{ fontSize: "1.2em" }}>→</span>
        </a>
      </div>
    </PageLayout>
  );
}
