import { useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { motion, useScroll, useTransform } from "framer-motion";
import {
  ArrowUp, Award, BadgeCheck, Bot, Brain, ChevronDown, CircleDollarSign, Cpu, Globe,
  Lock, MessageSquare, Phone, Play, Rocket, ShieldCheck, Smartphone, Sparkles, Star,
  TrendingUp, Zap, Mail, MapPin, Twitter, Linkedin, Send, Youtube, Instagram, Check,
  Crown, User, ShoppingBag, ShoppingCart, Plus,
} from "lucide-react";
import { AuroraBackground } from "./AuroraBackground";
import { HeroAurora } from "./HeroAurora";
import { MovingAnimatedBackground } from "./MovingAnimatedBackground";
import { Navbar } from "./Navbar";
import { Counter, MagneticButton, TiltCard } from "./Primitives";
import { CandlestickChart } from "./CandlestickChart";
import { PremiumCircularChart } from "./PremiumCircularChart";

/* ---------------- Boot sequence ---------------- */
export function Boot({ onDone }: { onDone: () => void }) {
  useEffect(() => {
    const t = setTimeout(onDone, 3400);
    return () => clearTimeout(t);
  }, [onDone]);
  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] grid place-items-center"
      style={{ background: "radial-gradient(circle at 50% 50%, #1a0b3d 0%, #0d0420 60%, #07021a 100%)" }}
    >
      <div className="relative grid place-items-center">
        {/* particle ring assembling */}
        <motion.div
          className="absolute h-48 w-48 rounded-full ring-conic-neon blur-[6px] opacity-90"
          initial={{ scale: 0.4, opacity: 0 }}
          animate={{ scale: 1, opacity: 0.9, rotate: 360 }}
          transition={{ duration: 2.4, ease: "easeOut" }}
        />
        <motion.div
          className="absolute h-56 w-56 rounded-full border"
          style={{ borderColor: "rgba(100,181,246,0.4)", boxShadow: "0 0 32px rgba(100,181,246,0.25)" }}
          initial={{ scale: 0 }}
          animate={{ scale: [0, 1.4, 1] }}
          transition={{ duration: 2, times: [0, 0.7, 1] }}
        />
        <motion.div
          className="absolute h-72 w-72 rounded-full border"
          style={{ borderColor: "rgba(186,104,200,0.3)", boxShadow: "0 0 40px rgba(186,104,200,0.20)" }}
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: [0, 2, 0], opacity: [0, 0.6, 0] }}
          transition={{ duration: 2.4, delay: 1, ease: "easeOut" }}
        />
        <motion.h1
          initial={{ y: 20, opacity: 0, filter: "blur(20px)" }}
          animate={{ y: 0, opacity: 1, filter: "blur(0px)" }}
          transition={{ duration: 1.2, delay: 0.6 }}
          className="gradient-text relative font-display text-5xl font-extrabold tracking-tight sm:text-7xl"
          style={{ filter: "drop-shadow(0 0 32px rgba(100,181,246,0.4))" }}
        >
          ARTRIX
        </motion.h1>
      </div>
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.6 }}
        className="absolute bottom-16 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.4em]"
        style={{ color: "#64b5f6", textShadow: "0 0 8px rgba(100,181,246,0.6)" }}
      >
        <span className="inline-block h-1.5 w-1.5 rounded-full bg-[#64b5f6]" style={{ animation: "blink 1s steps(1) infinite" }} />
        Initializing Neural Engine
      </motion.div>
      <motion.div
        initial={{ y: 0 }}
        animate={{ y: "-100%" }}
        transition={{ duration: 0.8, delay: 2.6, ease: [0.7, 0, 0.2, 1] }}
        className="absolute inset-0"
        style={{ background: "linear-gradient(180deg, #64b5f6 0%, #ba68c8 50%, #0d0420 100%)" }}
      />
    </motion.div>
  );
}

/* ---------------- Scroll Progress Ring ---------------- */
export function ProgressRing() {
  const { scrollYProgress } = useScroll();
  const [pct, setPct] = useState(0);
  useEffect(() => scrollYProgress.on("change", (v) => setPct(Math.round(v * 100))), [scrollYProgress]);
  const dash = useTransform(scrollYProgress, (v) => `${v * 175.9} 175.9`);
  return (
    <div className="fixed bottom-6 right-6 z-40 hidden md:block">
      <div className="relative grid h-16 w-16 place-items-center glass rounded-full">
        <svg className="absolute inset-0 -rotate-90" viewBox="0 0 64 64">
          <circle cx="32" cy="32" r="28" stroke="rgba(255,255,255,0.08)" strokeWidth="3" fill="none" />
          <motion.circle
            cx="32" cy="32" r="28" fill="none" strokeWidth="3" strokeLinecap="round"
            stroke="url(#ringG)" style={{ strokeDasharray: dash as any }}
          />
          <defs>
            <linearGradient id="ringG" x1="0" x2="1">
              <stop offset="0" stopColor="#ffb74d" />
              <stop offset="1" stopColor="#ba68c8" />
            </linearGradient>
          </defs>
        </svg>
        <span className="relative text-xs font-bold tabular-nums text-foreground/80">{pct}%</span>
      </div>
    </div>
  );
}

/* ---------------- Reveal helper ---------------- */
const reveal: any = {
  hidden: { y: 30, opacity: 0, filter: "blur(12px)" },
  show: (i: number = 0) => ({
    y: 0, opacity: 1, filter: "blur(0px)",
    transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1], delay: i * 0.08 },
  }),
};

/* ---------------- Typing effect ---------------- */
function Typing({ text }: { text: string }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    const t = setTimeout(() => setN((v) => Math.min(text.length, v + 1)), 25);
    return () => clearTimeout(t);
  }, [n, text.length]);
  return (
    <span>
      {text.slice(0, n)}
      <span className="ml-0.5 inline-block h-5 w-[2px] translate-y-1 bg-[#ffd180]" style={{ animation: "blink 1s steps(1) infinite" }} />
    </span>
  );
}

/* ---------------- Morphing blobs ---------------- */
function Blobs() {
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 -z-10 overflow-hidden">
      <div className="absolute -left-32 top-20 h-[28rem] w-[28rem] opacity-40 blur-3xl"
        style={{ background: "radial-gradient(circle, rgba(255,183,77,0.6), transparent 60%)", animation: "blob-morph 14s ease-in-out infinite, float-slow 16s ease-in-out infinite" }} />
      <div className="absolute right-[-10%] top-[40%] h-[32rem] w-[32rem] opacity-40 blur-3xl"
        style={{ background: "radial-gradient(circle, rgba(186,104,200,0.6), transparent 60%)", animation: "blob-morph 18s ease-in-out infinite reverse, float-slow 22s ease-in-out infinite" }} />
      <div className="absolute left-[30%] top-[80%] h-[26rem] w-[26rem] opacity-30 blur-3xl"
        style={{ background: "radial-gradient(circle, rgba(100,181,246,0.6), transparent 60%)", animation: "blob-morph 20s ease-in-out infinite" }} />
    </div>
  );
}

/* ---------------- HERO ---------------- */
export function Hero() {
  const ref = useRef<HTMLDivElement | null>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const y1 = useTransform(scrollYProgress, [0, 1], [0, 120]);
  const y2 = useTransform(scrollYProgress, [0, 1], [0, -80]);

  return (
    <section ref={ref} id="home" className="relative isolate flex min-h-screen items-center overflow-hidden pt-28">
      {/* Moving animated background is now global via MovingAnimatedBackground */}
      <div className="mx-auto grid w-full max-w-7xl gap-12 px-4 sm:px-6 lg:grid-cols-12 lg:gap-8">
        <motion.div style={{ y: y2 }} className="lg:col-span-7">
          {/* === AI · SIGNAL INTELLIGENCE badge — EXACT reference (white text, no glow) === */}
          <motion.div
            initial="hidden" animate="show" variants={reveal}
            className="inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-xs"
            style={{
              background: "rgba(255, 255, 255, 0.06)",
              border: "1px solid rgba(255, 255, 255, 0.15)",
              color: "#FFFFFF",
              fontWeight: 500,
              fontSize: "14px",
              letterSpacing: "0.05em",
              textTransform: "uppercase",
            }}
          >
            <Sparkles className="h-3 w-3" style={{ color: "#B39DDB" }} />
            AI · SIGNAL INTELLIGENCE
          </motion.div>

          {/* === WORLD-CLASS HEADLINE — EXACT reference colors (solid, no gradient, no glow) ===
              "Trade with the precision of an institution."
              "precision" → #81D4FA light blue (SOLID)
              "of an" → #FFD54F yellow (SOLID)
              "institution." → #FFB74D orange (SOLID, with period) */}
          <motion.h1
            initial="hidden" animate="show" variants={reveal} custom={1}
            className="mt-6 font-display text-5xl font-extrabold leading-[0.95] tracking-tight sm:text-7xl lg:text-[5.5rem]"
          >
            <span
              className="block"
              style={{
                color: "#FFFFFF",
                fontWeight: 700,
              }}
            >
              ARTRIX SOFTWARE
            </span>
            <span className="mt-4 block text-2xl font-bold leading-tight sm:text-4xl lg:text-5xl">
              <span style={{ color: "#FFFFFF" }}>Trade with the </span>
              {/* "precision" — EXACT reference #81D4FA light blue, SOLID */}
              <span style={{ color: "#81D4FA", fontWeight: 700 }}>precision</span>{" "}
              {/* "of an" — EXACT reference #FFD54F yellow, SOLID */}
              <span style={{ color: "#FFD54F", fontWeight: 700 }}>of an</span>{" "}
              {/* "institution." — EXACT reference #FFB74D orange, SOLID, with period */}
              <span style={{ color: "#FFB74D", fontWeight: 700 }}>institution.</span>
            </span>
          </motion.h1>

          <motion.p
            initial="hidden" animate="show" variants={reveal} custom={2}
            className="mt-6 max-w-xl text-base sm:text-lg"
            style={{ color: "#E0E0E0", lineHeight: 1.5, fontWeight: 400 }}
          >
            ARTRIX reads charts in seconds and returns a single, decisive call — distilled from candle psychology, multi-frame price action and volume conviction. Built for binary, forex and OTC traders who don't have time to second-guess.
          </motion.p>

          {/* === Premium CTA buttons — WHITE "See Products" + DARK Sign In === */}
          <motion.div initial="hidden" animate="show" variants={reveal} custom={3} className="mt-8 flex flex-wrap items-center gap-4">
            <Link to="/products">
              <MagneticButton as="button" className="btn-primary btn-primary-pulse inline-flex items-center gap-2 rounded-2xl px-6 py-3.5 text-base">
                See Products <span style={{ fontSize: "1.2em" }}>→</span>
              </MagneticButton>
            </Link>
            <Link to="/contact">
              <MagneticButton as="button" className="btn-secondary inline-flex items-center gap-2 rounded-2xl px-6 py-3.5 text-base font-semibold">
                <User className="h-4 w-4" /> Sign In
              </MagneticButton>
            </Link>
          </motion.div>

          {/* Bottom badges — EXACT reference: '57 OTC markets · live payout sync' + 'Encrypted by default' */}
          <motion.div initial="hidden" animate="show" variants={reveal} custom={4} className="mt-10 flex flex-wrap gap-3 text-xs">
            <span
              className="inline-flex items-center gap-2 rounded-full px-3 py-1.5"
              style={{
                color: "#E0E0E0",
                background: "rgba(255, 255, 255, 0.06)",
                border: "1px solid rgba(255, 255, 255, 0.12)",
                fontWeight: 400,
                fontSize: "14px",
              }}
            >
              <span
                className="grid h-4 w-4 place-items-center rounded-full"
                style={{
                  background: "rgba(0, 191, 165, 0.15)",
                  border: "1px solid rgba(0, 191, 165, 0.40)",
                }}
              >
                <span className="h-1.5 w-1.5 rounded-full" style={{ background: "#00BFA5", boxShadow: "0 0 6px #00BFA5" }} />
              </span>
              57 OTC markets · live payout sync
            </span>
            <span
              className="inline-flex items-center gap-2 rounded-full px-3 py-1.5"
              style={{
                color: "#E0E0E0",
                background: "rgba(255, 255, 255, 0.06)",
                border: "1px solid rgba(255, 255, 255, 0.12)",
                fontWeight: 400,
                fontSize: "14px",
              }}
            >
              <span
                className="grid h-4 w-4 place-items-center rounded-full"
                style={{
                  background: "rgba(157, 91, 255, 0.15)",
                  border: "1px solid rgba(157, 91, 255, 0.40)",
                }}
              >
                <Lock className="h-2 w-2" style={{ color: "#9D5BFF" }} />
              </span>
              Encrypted by default
            </span>
          </motion.div>
        </motion.div>

        {/* === HERO PROFIT DASHBOARD — CLEAN (no duplicates) === */}
        <motion.div style={{ y: y1 }} className="relative lg:col-span-5">
          <TiltCard
            className="relative rounded-3xl p-6 overflow-hidden"
            style={{
              background: "linear-gradient(180deg, #1A0033 0%, #0F172A 55%, #050810 100%)",
              border: "1px solid rgba(0, 191, 165, 0.25)",
              boxShadow: "0 0 60px -10px rgba(0, 191, 165, 0.35), 0 30px 80px -40px rgba(157, 91, 255, 0.50), inset 0 1px 0 rgba(255,255,255,0.06)",
            }}
          >
            {/* Subtle dotted grid overlay — like reference */}
            <div
              aria-hidden
              className="pointer-events-none absolute inset-0 opacity-40"
              style={{
                backgroundImage:
                  "radial-gradient(circle at 1px 1px, rgba(0, 191, 165, 0.10) 1px, transparent 0)",
                backgroundSize: "20px 20px",
              }}
            />

            {/* Top status row — Bot Active only (Sign in is in hero CTA, no duplicate) */}
            <div className="relative flex items-center justify-center">
              <div className="flex items-center gap-2">
                <span className="relative grid h-2.5 w-2.5 place-items-center">
                  <span className="absolute h-full w-full rounded-full bg-[#00BFA5]" />
                  <span className="absolute h-full w-full rounded-full bg-[#00BFA5]" style={{ animation: "ping-soft 1.6s ease-out infinite" }} />
                </span>
                <span
                  className="text-xs font-semibold uppercase tracking-wider"
                  style={{ color: "#00BFA5", textShadow: "0 0 8px rgba(0,191,165,0.6)" }}
                >
                  Bot Active
                </span>
              </div>
            </div>

            {/* === EXACT REPLICA: Circular chart + WIN RATE + 2 bottom cards === */}
            <div className="relative mt-6">
              <PremiumCircularChart />
            </div>
          </TiltCard>

          {/* Floating orbiting coins — kept for premium feel */}
          <motion.div
            aria-hidden
            className="pointer-events-none absolute -right-4 -bottom-4 grid h-12 w-12 place-items-center rounded-full"
            style={{
              background: "rgba(20, 20, 30, 0.75)",
              border: "1px solid rgba(255, 215, 0, 0.40)",
              backdropFilter: "blur(12px)",
              boxShadow: "0 0 24px -4px rgba(255, 215, 0, 0.55)",
            }}
            animate={{ y: [0, -12, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          >
            <CircleDollarSign className="h-6 w-6" style={{ color: "#FFD700", filter: "drop-shadow(0 0 8px rgba(255,215,0,0.7))" }} />
          </motion.div>
          <motion.div
            aria-hidden
            className="pointer-events-none absolute -left-3 top-1/3 grid h-11 w-11 place-items-center rounded-full"
            style={{
              background: "rgba(20, 20, 30, 0.75)",
              border: "1px solid rgba(157, 91, 255, 0.40)",
              backdropFilter: "blur(12px)",
              boxShadow: "0 0 24px -4px rgba(157, 91, 255, 0.55)",
            }}
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
          >
            <TrendingUp className="h-5 w-5" style={{ color: "#9D5BFF", filter: "drop-shadow(0 0 8px rgba(157,91,255,0.7))" }} />
          </motion.div>
        </motion.div>
      </div>

      <Link to="/products" aria-label="See Products" className="absolute bottom-6 left-1/2 -translate-x-1/2 text-foreground/50 hover:text-foreground transition">
        <ChevronDown className="h-6 w-6" style={{ animation: "scroll-bounce 1.8s ease-in-out infinite" }} />
      </Link>
    </section>
  );
}

/* ---------------- Stats Marquee ---------------- */
export function StatsMarquee() {
  const items = [
    "100% Conversion Rate", "50,000+ Traders", "$2.4B+ Profit Generated",
    "99.98% Uptime", "180+ Countries", "4.9★ Rating", "0.01s Execution",
  ];
  return (
    <section
      id="stats"
      className="relative border-y py-8"
      style={{
        borderColor: "rgba(100,181,246,0.15)",
        background: "linear-gradient(90deg, rgba(20,18,46,0.6), rgba(12,11,34,0.7), rgba(20,18,46,0.6))",
        boxShadow: "inset 0 1px 0 rgba(100,181,246,0.10), inset 0 -1px 0 rgba(186,104,200,0.10)",
      }}
    >
      <div
        className="relative overflow-hidden"
        style={{ maskImage: "linear-gradient(90deg, transparent, #000 10%, #000 90%, transparent)" }}
      >
        <div className="flex w-max gap-12 whitespace-nowrap" style={{ animation: "marquee 38s linear infinite" }}>
          {[...items, ...items, ...items].map((t, i) => (
            <span
              key={i}
              className="text-2xl font-extrabold tracking-tight sm:text-4xl"
              style={{
                background: "linear-gradient(120deg, #ffd180, #ffb74d 35%, #64b5f6 70%, #ba68c8 100%)",
                WebkitBackgroundClip: "text",
                backgroundClip: "text",
                color: "transparent",
                filter: "drop-shadow(0 0 12px rgba(100,181,246,0.15))",
              }}
            >
              {t} <span className="mx-6 text-[#64b5f6]" style={{ opacity: 0.5, textShadow: "0 0 8px rgba(100,181,246,0.6)" }}>✦</span>
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- SHOP ---------------- */
export function Shop() {
  const tiers = [
    {
      name: "Starter", price: "$49", priceNum: 49, per: "/mo", best: false, badge: "For Beginners",
      roi: "Up to 15% / mo",
      features: ["1 active bot", "3 trading pairs", "Basic AI engine", "Email support"],
      cta: "Buy Now",
    },
    {
      name: "Pro", price: "$149", priceNum: 149, per: "/mo", best: true, badge: "🔥 Best Seller",
      roi: "Up to 35% / mo",
      features: ["3 active bots", "15 trading pairs", "Advanced AI engine", "Priority support", "Mobile app"],
      cta: "Buy Now",
    },
    {
      name: "Elite", price: "$399", priceNum: 399, per: "/mo", best: false, badge: "For Serious Traders",
      roi: "Up to 65% / mo",
      features: ["10 active bots", "Unlimited pairs", "Neural AI engine", "1-on-1 strategist", "Full API access"],
      cta: "Buy Now",
    },
    {
      name: "Institutional", price: "Custom", priceNum: 0, per: "", best: false, badge: "Enterprise Grade",
      roi: "Unlimited ROI",
      features: ["Unlimited bots", "White-glove onboarding", "Dedicated server", "Custom strategies", "99.99% SLA"],
      cta: "Contact Sales",
    },
  ];

  const [amount, setAmount] = useState(10000);
  const [tier, setTier] = useState(1);
  const roiMap = [0.15, 0.35, 0.65, 1.2];
  const profit = Math.round(amount * roiMap[tier]);
  const burst = (e: React.MouseEvent) => spawnConfetti(e.clientX, e.clientY);

  // === Cart state ===
  const [cart, setCart] = useState<Record<string, number>>({});
  const [toast, setToast] = useState<string | null>(null);
  const [justAdded, setJustAdded] = useState<string | null>(null);

  const addToCart = (tierName: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setCart((c) => ({ ...c, [tierName]: (c[tierName] || 0) + 1 }));
    setToast(`✓ ${tierName} added to cart`);
    setJustAdded(tierName);
    spawnConfetti(e.clientX, e.clientY);
    setTimeout(() => setToast(null), 2500);
    setTimeout(() => setJustAdded(null), 1200);
  };

  const cartCount = Object.values(cart).reduce((a, b) => a + b, 0);
  const cartTotal = Object.entries(cart).reduce((sum, [name, qty]) => {
    const t = tiers.find((x) => x.name === name);
    return sum + (t ? t.priceNum * qty : 0);
  }, 0);

  return (
    <section id="shop" className="relative py-28">
      {/* Money management ambient glow */}
      <div className="absolute inset-0 -z-10 pointer-events-none">
        <div
          className="absolute top-20 left-1/4 h-[28rem] w-[28rem] rounded-full blur-3xl opacity-30"
          style={{ background: "radial-gradient(circle, rgba(100,181,246,0.35), transparent 60%)" }}
        />
        <div
          className="absolute bottom-20 right-1/4 h-[32rem] w-[32rem] rounded-full blur-3xl opacity-30"
          style={{ background: "radial-gradient(circle, rgba(255,183,77,0.35), transparent 60%)" }}
        />
      </div>

      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="Shop · Trading Bots"
          title="Choose Your Profit Engine"
          subtitle="A‑to‑Z trading bots for every ambition. Pick a tier, plug in, and let the bots work."
        />

        {/* Premium pricing tiers */}
        <div className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {tiers.map((t, i) => (
            <motion.div
              key={t.name}
              variants={reveal} initial="hidden" whileInView="show" viewport={{ once: true, margin: "-80px" }} custom={i}
            >
              <TiltCard
                className={`relative h-full overflow-hidden rounded-3xl p-6 ${
                  t.best
                    ? "glass-gold lg:scale-[1.04]"
                    : "glass-strong"
                }`}
              >
                {/* Animated gradient border for best seller */}
                {t.best && (
                  <div
                    aria-hidden
                    className="pointer-events-none absolute -inset-px rounded-3xl opacity-80"
                    style={{
                      background: "linear-gradient(120deg, rgba(255,183,77,0.6), rgba(100,181,246,0.4), rgba(186,104,200,0.4), rgba(255,183,77,0.6))",
                      backgroundSize: "300% 300%",
                      animation: "gradient-shift 6s ease infinite",
                      padding: "1px",
                      WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)",
                      WebkitMaskComposite: "xor",
                      maskComposite: "exclude",
                    }}
                  />
                )}

                {/* Badge */}
                {t.best && (
                  <span
                    className="absolute right-4 top-4 inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider"
                    style={{
                      color: "#1a0b3d",
                      background: "linear-gradient(135deg, #ffd180, #ffb74d 50%, #ff9100)",
                      boxShadow: "0 0 18px rgba(255,183,77,0.7)",
                    }}
                  >
                    {t.badge}
                  </span>
                )}
                {!t.best && (
                  <span className="absolute right-4 top-4 rounded-full glass px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider text-foreground/70">
                    {t.badge}
                  </span>
                )}

                <h3
                  className="font-display text-2xl font-bold"
                  style={t.best ? { color: "#ffb74d", textShadow: "0 0 12px rgba(255,183,77,0.5)" } : undefined}
                >
                  {t.name}
                </h3>

                {/* Price */}
                <div className="mt-2 flex items-end gap-1">
                  <span
                    className="text-5xl font-extrabold"
                    style={{
                      background: t.best
                        ? "linear-gradient(120deg, #fff3b0, #ffb74d 50%, #ff9100)"
                        : "linear-gradient(120deg, #ffd180, #ffb74d 40%, #64b5f6 100%)",
                      WebkitBackgroundClip: "text",
                      backgroundClip: "text",
                      color: "transparent",
                      filter: t.best ? "drop-shadow(0 0 14px rgba(255,183,77,0.55))" : "drop-shadow(0 0 10px rgba(100,181,246,0.20))",
                    }}
                  >
                    {t.price}
                  </span>
                  <span className="pb-1.5 text-sm text-foreground/60">{t.per}</span>
                </div>

                {/* ROI badge */}
                <div
                  className="mt-1 inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-semibold"
                  style={{
                    background: "rgba(100,181,246,0.10)",
                    border: "1px solid rgba(100,181,246,0.30)",
                    color: "#64b5f6",
                  }}
                >
                  <TrendingUp className="h-3.5 w-3.5" /> {t.roi}
                </div>

                {/* Stars */}
                <div className="mt-3 flex gap-0.5" style={{ color: "#ffb74d" }}>
                  {Array.from({ length: 5 }).map((_, k) => (
                    <Star
                      key={k}
                      className="h-3.5 w-3.5 fill-current"
                      style={{ filter: "drop-shadow(0 0 4px rgba(255,183,77,0.5))" }}
                    />
                  ))}
                </div>

                {/* Features list */}
                <ul className="mt-5 space-y-2 text-sm">
                  {t.features.map((f) => (
                    <li key={f} className="flex items-start gap-2 text-foreground/80">
                      <Check
                        className="mt-0.5 h-4 w-4 shrink-0"
                        style={{ color: "#64b5f6", filter: "drop-shadow(0 0 4px rgba(100,181,246,0.5))" }}
                      />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>

                {/* === TWO WORKING BUTTONS: Buy Now + Add to Cart === */}
                <div className="mt-6 space-y-2">
                  {/* Buy Now — primary action */}
                  <MagneticButton
                    onClick={burst}
                    className={`inline-flex w-full items-center justify-center gap-2 rounded-2xl px-4 py-3 text-sm font-bold ${
                      t.best ? "btn-primary btn-primary-pulse" : "btn-secondary"
                    }`}
                  >
                    {t.cta} <Rocket className="h-4 w-4" />
                  </MagneticButton>

                  {/* Add to Cart — secondary action (only for priced tiers) */}
                  {t.priceNum > 0 && (
                    <button
                      onClick={(e) => addToCart(t.name, e)}
                      className={`inline-flex w-full items-center justify-center gap-2 rounded-2xl px-4 py-3 text-sm font-bold transition-all duration-300 relative overflow-hidden ${
                        justAdded === t.name
                          ? "btn-primary"
                          : "glass text-foreground hover:bg-white/10"
                      }`}
                      style={{
                        borderColor: justAdded === t.name
                          ? "rgba(0, 191, 165, 0.6)"
                          : "rgba(0, 191, 165, 0.30)",
                      }}
                    >
                      {justAdded === t.name ? (
                        <>
                          <Check className="h-4 w-4" /> Added to Cart!
                        </>
                      ) : (
                        <>
                          <ShoppingCart className="h-4 w-4" />
                          Add to Cart
                          {cart[t.name] > 0 && (
                            <span
                              className="ml-1 inline-flex h-5 min-w-5 items-center justify-center rounded-full px-1.5 text-[10px] font-bold"
                              style={{
                                background: "#00BFA5",
                                color: "#050810",
                                boxShadow: "0 0 8px rgba(0, 191, 165, 0.7)",
                              }}
                            >
                              {cart[t.name]}
                            </span>
                          )}
                        </>
                      )}
                    </button>
                  )}
                </div>
              </TiltCard>
            </motion.div>
          ))}
        </div>

        {/* === PREMIUM ROI CALCULATOR — MONEY MANAGEMENT CENTERPIECE === */}
        <motion.div
          variants={reveal} initial="hidden" whileInView="show" viewport={{ once: true }}
          className="glass-strong mt-16 rounded-3xl p-6 sm:p-10 relative overflow-hidden"
        >
          {/* Decorative scan line */}
          <div
            aria-hidden
            className="pointer-events-none absolute inset-0 opacity-50"
            style={{
              background: "linear-gradient(180deg, transparent 0%, rgba(100,181,246,0.04) 50%, transparent 100%)",
              backgroundSize: "100% 4px",
            }}
          />

          <div className="grid items-center gap-8 lg:grid-cols-2">
            <div className="relative">
              <div
                className="text-xs font-semibold uppercase tracking-[0.3em]"
                style={{ color: "#64b5f6", textShadow: "0 0 8px rgba(100,181,246,0.5)" }}
              >
                ROI Calculator
              </div>
              <h3 className="mt-2 font-display text-3xl font-bold sm:text-4xl">
                <span className="gradient-text-cyan">See Your Projected Profit</span>
              </h3>
              <p className="mt-2 text-foreground/70">Drag, pick a tier, watch your monthly profit ignite.</p>

              <label className="mt-6 block text-xs font-semibold uppercase tracking-wider text-foreground/60">Investment</label>
              <div className="mt-2 flex items-center gap-4">
                <input
                  type="range" min={100} max={1000000} step={100} value={amount}
                  onChange={(e) => setAmount(Number(e.target.value))}
                  className="flex-1"
                />
                <div
                  className="w-32 rounded-xl glass px-3 py-2 text-right font-bold tabular-nums"
                  style={{ borderColor: "rgba(100,181,246,0.30)", boxShadow: "0 0 18px -8px rgba(100,181,246,0.45)" }}
                >
                  ${amount.toLocaleString()}
                </div>
              </div>

              <label className="mt-6 block text-xs font-semibold uppercase tracking-wider text-foreground/60">Bot Tier</label>
              <div className="mt-2 flex flex-wrap gap-2">
                {tiers.map((t, i) => (
                  <button
                    key={t.name}
                    onClick={() => setTier(i)}
                    className={`rounded-xl px-3 py-2 text-sm font-semibold transition ${
                      tier === i ? "btn-primary btn-primary-pulse" : "glass text-foreground/80 hover:bg-white/5"
                    }`}
                  >
                    {t.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Profit projection panel */}
            <div className="relative">
              <div
                className="rounded-3xl p-6 text-center relative overflow-hidden"
                style={{
                  background: "linear-gradient(180deg, rgba(100,181,246,0.08), rgba(186,104,200,0.04))",
                  border: "1px solid rgba(100,181,246,0.30)",
                  boxShadow: "inset 0 1px 0 rgba(255,255,255,0.08), 0 30px 80px -40px rgba(100,181,246,0.5)",
                }}
              >
                {/* Pulse ring around the profit number */}
                <div
                  aria-hidden
                  className="pointer-events-none absolute left-1/2 top-[55%] h-48 w-48 -translate-x-1/2 -translate-y-1/2 rounded-full"
                  style={{
                    background: "radial-gradient(circle, rgba(255,183,77,0.20), transparent 70%)",
                    animation: "glow-pulse 3s ease-in-out infinite",
                  }}
                />
                <div className="relative">
                  <div className="text-xs font-semibold uppercase tracking-wider text-foreground/60">Projected Monthly Profit</div>
                  <div
                    onClick={(e) => spawnConfetti(e.clientX, e.clientY, true)}
                    className="mt-3 cursor-pointer font-display text-5xl font-extrabold tabular-nums sm:text-6xl"
                    style={{
                      background: "linear-gradient(120deg, #fff3b0, #ffb74d 40%, #64b5f6 90%)",
                      WebkitBackgroundClip: "text",
                      backgroundClip: "text",
                      color: "transparent",
                      filter: "drop-shadow(0 0 24px rgba(255,183,77,0.55))",
                    }}
                  >
                    ${profit.toLocaleString()}
                  </div>
                  <div
                    className="mt-1 text-sm font-bold"
                    style={{ color: "#64b5f6", textShadow: "0 0 8px rgba(100,181,246,0.6)" }}
                  >
                    +{Math.round(roiMap[tier] * 100)}% ROI
                  </div>

                  {/* Premium growing bars with glow */}
                  <div className="mt-6 flex h-32 items-end justify-center gap-2">
                    {[0.35, 0.5, 0.7, 0.85, 1].map((s, i) => (
                      <div
                        key={i}
                        className="w-7 rounded-t-md relative"
                        style={{
                          height: `${s * roiMap[tier] * 90 + 10}%`,
                          transition: "height .6s cubic-bezier(0.16, 1, 0.3, 1)",
                          background: "linear-gradient(180deg, #64b5f6 0%, #ba68c8 60%, #ffb74d 100%)",
                          boxShadow: "0 0 18px -2px rgba(100,181,246,0.65), 0 0 30px -4px rgba(186,104,200,0.45)",
                        }}
                      >
                        <span
                          className="absolute inset-x-0 top-0 h-1/3 rounded-t-md"
                          style={{ background: "linear-gradient(180deg, rgba(255,255,255,0.4), transparent)" }}
                        />
                      </div>
                    ))}
                  </div>
                  <div className="mt-4 flex flex-wrap items-center justify-center gap-2 text-[10px] font-semibold uppercase tracking-wider text-foreground/60">
                    {["Visa", "Mastercard", "PayPal", "Crypto", "Apple Pay", "UPI"].map((p) => (
                      <span
                        key={p}
                        className="rounded-md px-2 py-1"
                        style={{
                          background: "rgba(255,255,255,0.04)",
                          border: "1px solid rgba(255,255,255,0.08)",
                        }}
                      >
                        {p}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* === CART SUMMARY BAR (shows when cart has items) === */}
        {cartCount > 0 && (
          <motion.div
            initial={{ y: 60, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="fixed bottom-20 left-1/2 z-40 -translate-x-1/2 md:bottom-6"
          >
            <div
              className="flex items-center gap-4 rounded-2xl px-5 py-3"
              style={{
                background: "linear-gradient(135deg, rgba(0, 191, 165, 0.18), rgba(157, 91, 255, 0.18))",
                border: "1px solid rgba(0, 191, 165, 0.45)",
                backdropFilter: "blur(20px) saturate(180%)",
                WebkitBackdropFilter: "blur(20px) saturate(180%)",
                boxShadow: "0 0 40px -8px rgba(0, 191, 165, 0.55), 0 20px 60px -20px rgba(0,0,0,0.7)",
              }}
            >
              <div className="flex items-center gap-2">
                <span
                  className="grid h-9 w-9 place-items-center rounded-full"
                  style={{ background: "#00BFA5", color: "#050810" }}
                >
                  <ShoppingCart className="h-4 w-4" />
                </span>
                <div className="leading-tight">
                  <div className="text-xs font-medium uppercase tracking-wider" style={{ color: "#E0E0E0" }}>
                    {cartCount} item{cartCount > 1 ? "s" : ""} in cart
                  </div>
                  <div className="text-lg font-bold tabular-nums" style={{ color: "#FFD700", textShadow: "0 0 10px rgba(255,215,0,0.5)" }}>
                    ${cartTotal.toLocaleString()}
                  </div>
                </div>
              </div>
              <a
                href="#contact"
                className="btn-primary inline-flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-bold"
                onClick={(e) => {
                  e.preventDefault();
                  setToast(`✓ Checkout initiated for ${cartCount} item(s) — $${cartTotal.toLocaleString()}`);
                  setTimeout(() => setToast(null), 3000);
                }}
              >
                Checkout <span style={{ fontSize: "1.1em" }}>→</span>
              </a>
              <button
                onClick={() => { setCart({}); setToast("Cart cleared"); setTimeout(() => setToast(null), 1800); }}
                className="rounded-xl px-3 py-2 text-xs font-semibold text-foreground/70 hover:bg-white/10 transition"
                aria-label="Clear cart"
              >
                Clear
              </button>
            </div>
          </motion.div>
        )}

        {/* === TOAST NOTIFICATION === */}
        {toast && (
          <motion.div
            initial={{ y: -40, opacity: 0, x: "-50%" }}
            animate={{ y: 0, opacity: 1, x: "-50%" }}
            exit={{ y: -40, opacity: 0, x: "-50%" }}
            className="fixed left-1/2 top-20 z-[80]"
          >
            <div
              className="flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold"
              style={{
                background: "linear-gradient(135deg, rgba(0, 191, 165, 0.25), rgba(157, 91, 255, 0.20))",
                border: "1px solid rgba(0, 191, 165, 0.55)",
                backdropFilter: "blur(20px) saturate(180%)",
                WebkitBackdropFilter: "blur(20px) saturate(180%)",
                boxShadow: "0 0 30px -6px rgba(0, 191, 165, 0.6), 0 12px 40px -10px rgba(0,0,0,0.5)",
                color: "#FFFFFF",
              }}
            >
              <Check className="h-4 w-4" style={{ color: "#00BFA5" }} />
              {toast}
            </div>
          </motion.div>
        )}
      </div>
    </section>
  );
}

export function SectionHeading({ eyebrow, title, subtitle }: { eyebrow: string; title: string; subtitle?: string }) {
  return (
    <motion.div
      variants={reveal} initial="hidden" whileInView="show" viewport={{ once: true, margin: "-80px" }}
      className="mx-auto max-w-3xl text-center"
    >
      <div
        className="inline-flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.4em]"
        style={{ color: "#64b5f6", textShadow: "0 0 8px rgba(100,181,246,0.5)" }}
      >
        <span className="h-px w-6" style={{ background: "linear-gradient(90deg, transparent, #64b5f6)" }} />
        {eyebrow}
        <span className="h-px w-6" style={{ background: "linear-gradient(90deg, #64b5f6, transparent)" }} />
      </div>
      <h2 className="mt-3 font-display text-4xl font-extrabold leading-tight sm:text-6xl">
        <span
          className="gradient-text"
          style={{ filter: "drop-shadow(0 4px 28px rgba(100,181,246,0.18))" }}
        >
          {title}
        </span>
      </h2>
      {subtitle && <p className="mx-auto mt-4 max-w-2xl text-foreground/70 sm:text-lg">{subtitle}</p>}
    </motion.div>
  );
}

/* ---------------- WHY ARTRIX ---------------- */
export function Features() {
  const features = [
    { icon: Brain, title: "Neural AI Engine", desc: "Deep learning that adapts to markets in real time." },
    { icon: Zap, title: "0.01s Execution", desc: "The fastest trade execution on the planet." },
    { icon: ShieldCheck, title: "Military-Grade Security", desc: "256-bit encryption, cold storage, 2FA." },
    { icon: BadgeCheck, title: "100% Conversion Guarantee", desc: "Our A‑to‑Z system turns every lead into profit." },
    { icon: Cpu, title: "24/7 Autopilot", desc: "Never sleeps. Never misses a trade." },
    { icon: Globe, title: "180+ Countries", desc: "Global exchange coverage, anywhere you trade." },
    { icon: Smartphone, title: "Mobile · Web · API", desc: "Trade from anywhere, on any device." },
    { icon: Award, title: "Award-Winning", desc: '"Best Trading Bot 2025" — Multiple awards.' },
  ];
  return (
    <section id="features" className="relative py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="Why ARTRIX"
          title="Outperforms Every Bot on Earth"
          subtitle="Eight unfair advantages engineered into a single, surgical platform."
        />
        <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              variants={reveal} initial="hidden" whileInView="show" viewport={{ once: true, margin: "-60px" }} custom={i}
            >
              <TiltCard className="group glass h-full rounded-2xl p-6 relative overflow-hidden transition-all duration-500">
                {/* Numbered badge "01", "02" like reference 4 */}
                <span
                  className="absolute right-4 top-4 font-mono text-xs font-bold tabular-nums opacity-50 transition-opacity group-hover:opacity-100"
                  style={{
                    color: "#ba68c8",
                    textShadow: "0 0 8px rgba(186,104,200,0.5)",
                  }}
                >
                  {String(i + 1).padStart(2, "0")}
                </span>

                <div
                  className="mb-4 inline-grid h-12 w-12 place-items-center rounded-xl ring-1 relative"
                  style={{
                    background: "linear-gradient(135deg, rgba(100,181,246,0.18), rgba(186,104,200,0.18))",
                    borderColor: "rgba(100,181,246,0.30)",
                    animation: "float-slow 6s ease-in-out infinite",
                  }}
                >
                  <f.icon
                    className="h-5 w-5"
                    style={{ color: "#64b5f6", filter: "drop-shadow(0 0 6px rgba(100,181,246,0.6))" }}
                  />
                </div>
                <h3 className="text-lg font-bold">{f.title}</h3>
                <p className="mt-1 text-sm text-foreground/65">{f.desc}</p>

                {/* Bottom accent line on hover */}
                <span
                  className="absolute bottom-0 left-0 h-[2px] w-0 transition-all duration-500 group-hover:w-full"
                  style={{
                    background: "linear-gradient(90deg, #64b5f6, #ba68c8, #ffb74d)",
                    boxShadow: "0 0 8px rgba(100,181,246,0.6)",
                  }}
                />
              </TiltCard>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- LIVE DEMO ---------------- */
export function LiveDemo() {
  const trades = [
    "BUY  BTC @ 67,420 → +$1,240",
    "SELL ETH @ 3,418  → +$680",
    "BUY  SOL @ 184.20 → +$412",
    "SELL XRP @ 0.62   → +$220",
    "BUY  AVAX @ 38.45 → +$540",
  ];
  const [feed, setFeed] = useState<string[]>([]);
  useEffect(() => {
    const t = setInterval(() => {
      setFeed((f) => [trades[Math.floor(Math.random() * trades.length)], ...f].slice(0, 8));
    }, 1100);
    return () => clearInterval(t);
  }, []);
  return (
    <section id="demo" className="relative py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="Live Profit Demo"
          title="Watch the Bots Print"
          subtitle="A live simulation of ARTRIX in action. This is what a normal Tuesday looks like."
        />
        <motion.div
          variants={reveal} initial="hidden" whileInView="show" viewport={{ once: true }}
          className="glass-strong mt-12 rounded-3xl p-4 sm:p-6 glow-cyan"
        >
          <div className="grid gap-4 lg:grid-cols-3">
            <div className="lg:col-span-2 rounded-2xl glass p-4">
              <div className="mb-2 flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider"
                  style={{ color: "#64b5f6", textShadow: "0 0 8px rgba(100,181,246,0.6)" }}
                >
                  <span className="relative grid h-2.5 w-2.5 place-items-center">
                    <span className="absolute h-full w-full rounded-full bg-[#64b5f6]" />
                    <span className="absolute h-full w-full rounded-full bg-[#64b5f6]" style={{ animation: "ping-soft 1.6s ease-out infinite" }} />
                  </span>
                  Bot Status: Trading
                </div>
                <div className="flex items-center gap-2">
                  <span className="status-pill" style={{ fontSize: "0.55rem", padding: "0.15rem 0.45rem" }}>LIVE</span>
                  <span className="text-xs text-foreground/60 font-mono">BTC / USDT · M1</span>
                </div>
              </div>
              <div className="h-72"><CandlestickChart /></div>
            </div>
            <div className="flex flex-col gap-4">
              <div
                className="rounded-2xl p-4"
                style={{
                  background: "linear-gradient(180deg, rgba(255,183,77,0.08), rgba(255,183,77,0.02))",
                  border: "1px solid rgba(255,183,77,0.25)",
                  boxShadow: "inset 0 1px 0 rgba(255,255,255,0.05)",
                }}
              >
                <div className="text-xs text-foreground/60">Live Profit Counter</div>
                <div
                  className="mt-1 text-4xl font-extrabold tabular-nums"
                  style={{
                    background: "linear-gradient(120deg, #fff3b0, #ffb74d 50%, #ff9100)",
                    WebkitBackgroundClip: "text",
                    backgroundClip: "text",
                    color: "transparent",
                    filter: "drop-shadow(0 0 14px rgba(255,183,77,0.55))",
                  }}
                >
                  $<Counter to={1042871} duration={3.2} />
                </div>
              </div>
              <div className="rounded-2xl glass p-4">
                <div className="mb-2 text-xs font-semibold uppercase tracking-wider text-foreground/60">Trade Feed</div>
                <ul className="space-y-1.5 text-xs font-mono">
                  {feed.map((t, i) => (
                    <motion.li
                      key={t + i}
                      initial={{ x: -20, opacity: 0 }} animate={{ x: 0, opacity: 1 }}
                      className="flex items-center gap-2 text-foreground/80"
                    >
                      <span style={{ color: "#64b5f6", textShadow: "0 0 6px rgba(100,181,246,0.6)" }}>✓</span>{t}
                    </motion.li>
                  ))}
                </ul>
              </div>
              <div className="rounded-2xl glass p-4">
                <div className="text-xs text-foreground/60">ROI Gauge</div>
                <div className="relative mt-3 h-3 overflow-hidden rounded-full bg-white/5">
                  <div
                    className="absolute inset-y-0 left-0 w-[78%] rounded-full"
                    style={{
                      background: "linear-gradient(90deg, #64b5f6, #ba68c8)",
                      boxShadow: "0 0 12px rgba(100,181,246,0.7)",
                    }}
                  />
                </div>
                <div
                  className="mt-1 text-right text-xs font-bold"
                  style={{ color: "#64b5f6", textShadow: "0 0 6px rgba(100,181,246,0.5)" }}
                >
                  +78.4%
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

/* ---------------- ABOUT ---------------- */
export function About() {
  return (
    <section id="about" className="relative py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHeading eyebrow="About · Mission" title="The ARTRIX Mission" />
        <div className="mt-14 grid items-center gap-12 lg:grid-cols-2">
          <motion.div variants={reveal} initial="hidden" whileInView="show" viewport={{ once: true }} className="glass-strong rounded-3xl p-6">
            <div
              className="text-xs font-semibold uppercase tracking-[0.3em]"
              style={{ color: "#64b5f6", textShadow: "0 0 8px rgba(100,181,246,0.5)" }}
            >
              A → Z Conversion Funnel
            </div>
            <div className="mt-6 space-y-3">
              {[
                { l: "Analyze", d: "Markets scanned every millisecond.", c: "linear-gradient(135deg, #64b5f6, #ba68c8)" },
                { l: "Execute", d: "Sub-second order placement.", c: "linear-gradient(135deg, #ba68c8, #ffb74d)" },
                { l: "Optimize", d: "Neural feedback loop tunes strategy.", c: "linear-gradient(135deg, #ffb74d, #ffd180)" },
                { l: "Profit", d: "Gold pours into your account.", c: "linear-gradient(135deg, #ffd180, #ff9100)" },
              ].map((s, i) => (
                <div key={s.l} className="flex items-center gap-3">
                  <div
                    className="grid h-10 w-10 shrink-0 place-items-center rounded-xl font-bold text-[#0d0420]"
                    style={{
                      background: s.c,
                      boxShadow: "0 6px 22px -6px rgba(100,181,246,0.55)",
                    }}
                  >
                    {i + 1}
                  </div>
                  <div className="min-w-0">
                    <div className="font-bold">{s.l}</div>
                    <div className="text-sm text-foreground/65">{s.d}</div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div variants={reveal} initial="hidden" whileInView="show" viewport={{ once: true }} className="space-y-5 text-foreground/80">
            <p>Founded by elite quant engineers from the world's top hedge funds. ARTRIX exists for one reason: to democratize the trading edge that the 1% have kept to themselves for decades.</p>
            <p>Our mission is simple — make institutional-grade trading available to anyone with $49 and the courage to press start. Our vision is bigger — a world where everyone profits on autopilot.</p>
            <div className="grid grid-cols-2 gap-3 pt-4 sm:grid-cols-5">
              {[
                { l: "Users", v: 50000, s: "+" },
                { l: "Profit", v: 2.4, p: "$", s: "B+", d: 1 },
                { l: "Uptime", v: 99.98, s: "%", d: 2 },
                { l: "Countries", v: 180, s: "+" },
                { l: "Rating", v: 4.9, s: "★", d: 1 },
              ].map((s) => (
                <div key={s.l} className="glass rounded-xl p-3 text-center">
                  <div className="gradient-text-static text-xl font-extrabold">
                    {(s as any).p ?? ""}<Counter to={s.v} suffix={s.s} decimals={(s as any).d ?? 0} />
                  </div>
                  <div className="text-[10px] uppercase tracking-wider text-foreground/60">{s.l}</div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- TIMELINE ---------------- */
export function Timeline() {
  const events = [
    { y: "2019", t: "ARTRIX founded in a garage by 3 quant engineers", e: "💡" },
    { y: "2020", t: "First AI trading bot v1.0 launched", e: "🤖" },
    { y: "2021", t: "Crossed $100M profit generated for users", e: "📈" },
    { y: "2022", t: 'Won "Best Trading Bot" award', e: "🏆" },
    { y: "2023", t: "Expanded to 180+ countries · 50,000+ users", e: "🌍" },
    { y: "2024", t: "Launched Neural AI Engine v3.0", e: "🧠" },
    { y: "2025", t: "$2.4B+ total profit generated · IPO announced", e: "💎" },
    { y: "2026", t: "ARTRIX becomes world's #1 trading bot empire", e: "🚀" },
  ];
  const founders = [
    { n: "Aarav Mehta", r: "Co-Founder · CEO", b: "Ex-Goldman quant. Built the first ARTRIX engine in a garage." },
    { n: "Lin Zhao", r: "Co-Founder · CTO", b: "Architect of the Neural AI core. Stanford ML PhD." },
    { n: "Sofia Reyes", r: "Co-Founder · CFO", b: "Capital strategist. Scaled ARTRIX to 180+ markets." },
    { n: "Marcus Cole", r: "Head of Research", b: "Designs strategies that crush the benchmark every quarter." },
  ];
  return (
    <section id="history" className="relative py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHeading eyebrow="Developer History" title="The ARTRIX Journey" subtitle="From garage to empire — milestone by milestone." />
        <div className="relative mt-16">
          <div
            className="absolute left-4 top-0 h-full w-px md:left-1/2"
            style={{
              background: "linear-gradient(180deg, #64b5f6 0%, #ba68c8 50%, transparent 100%)",
              boxShadow: "0 0 12px rgba(100,181,246,0.5)",
            }}
          />
          <ul className="space-y-10">
            {events.map((e, i) => (
              <motion.li
                key={e.y}
                variants={reveal} initial="hidden" whileInView="show" viewport={{ once: true, margin: "-80px" }}
                className={`relative md:grid md:grid-cols-2 md:gap-12 ${i % 2 ? "md:[&>div:first-child]:order-2" : ""}`}
              >
                <div className={`relative pl-12 md:pl-0 ${i % 2 ? "md:text-left" : "md:text-right"}`}>
                  <span className="absolute left-0 top-1 grid h-8 w-8 place-items-center rounded-full ring-conic-neon md:left-1/2 md:-translate-x-1/2"
                    style={{ animation: "ring-spin 6s linear infinite", boxShadow: "0 0 18px rgba(100,181,246,0.5)" }}>
                    <span className="grid h-[26px] w-[26px] place-items-center rounded-full bg-[#0d0420]">{e.e}</span>
                  </span>
                  <div className={i % 2 ? "md:pl-12" : "md:pr-12"}>
                    <div className="gradient-text-static text-2xl font-extrabold">{e.y}</div>
                    <div className="mt-1 text-foreground/80">{e.t}</div>
                  </div>
                </div>
                <div />
              </motion.li>
            ))}
          </ul>
        </div>

        <div className="mt-20 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {founders.map((f, i) => (
            <motion.div key={f.n} variants={reveal} initial="hidden" whileInView="show" viewport={{ once: true }} custom={i}>
              <TiltCard className="glass h-full rounded-2xl p-5 text-center">
                <div className="relative mx-auto h-20 w-20">
                  <div className="absolute inset-0 rounded-full ring-conic-neon" style={{ animation: "ring-spin 10s linear infinite" }} />
                  <div className="absolute inset-[3px] grid place-items-center rounded-full bg-[#14122e] font-display text-2xl font-bold gradient-text-static">
                    {f.n[0]}
                  </div>
                </div>
                <h4 className="mt-4 font-bold">{f.n}</h4>
                <div
                  className="text-xs font-semibold uppercase tracking-wider"
                  style={{ color: "#64b5f6", textShadow: "0 0 6px rgba(100,181,246,0.4)" }}
                >
                  {f.r}
                </div>
                <p className="mt-2 text-xs text-foreground/65">{f.b}</p>
              </TiltCard>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- TESTIMONIALS ---------------- */
export function Testimonials() {
  const items = [
    { n: "Rajesh K.", c: "🇮🇳 India", q: "I made $84,000 in 3 months. ARTRIX changed my life.", p: "$84,000", s: 5 },
    { n: "Emily Carter", c: "🇺🇸 USA", q: "I sleep, the bots trade, I wake up richer. Surreal.", p: "$132,000", s: 5 },
    { n: "Tobias Müller", c: "🇩🇪 Germany", q: "Most polished trading product I've ever used. Period.", p: "$56,700", s: 5 },
    { n: "Sakura Tanaka", c: "🇯🇵 Japan", q: "The neural engine is on a different planet. Outstanding.", p: "$48,900", s: 5 },
    { n: "Lucas Silva", c: "🇧🇷 Brazil", q: "From zero to consistent monthly profit in 2 weeks.", p: "$22,400", s: 5 },
  ];
  return (
    <section id="testimonials" className="relative py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHeading eyebrow="Testimonials" title="Lives Changed by ARTRIX" />
        <div
          className="relative mt-12 overflow-hidden"
          style={{ maskImage: "linear-gradient(90deg, transparent, #000 8%, #000 92%, transparent)" }}
        >
          <div className="flex w-max gap-5" style={{ animation: "marquee 50s linear infinite" }}>
            {[...items, ...items].map((it, i) => (
              <div key={i} className="glass w-[320px] shrink-0 rounded-2xl p-5">
                <div className="flex items-center gap-3">
                  <div className="grid h-10 w-10 place-items-center rounded-full ring-conic-neon font-bold text-[#0d0420]">
                    <span className="grid h-[34px] w-[34px] place-items-center rounded-full bg-[#14122e] text-foreground">{it.n[0]}</span>
                  </div>
                  <div>
                    <div className="text-sm font-bold">{it.n}</div>
                    <div className="text-[11px] text-foreground/60">{it.c}</div>
                  </div>
                  <div
                    className="ml-auto text-xs font-bold"
                    style={{ color: "#64b5f6", textShadow: "0 0 6px rgba(100,181,246,0.5)" }}
                  >
                    {it.p}
                  </div>
                </div>
                <div className="mt-2 flex gap-0.5" style={{ color: "#ffb74d" }}>
                  {Array.from({ length: it.s }).map((_, k) => (
                    <Star key={k} className="h-3.5 w-3.5 fill-current" style={{ filter: "drop-shadow(0 0 3px rgba(255,183,77,0.5))" }} />
                  ))}
                </div>
                <p className="mt-3 text-sm text-foreground/80">"{it.q}"</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- FINAL CTA ---------------- */
export function FinalCTA() {
  const [time, setTime] = useState({ h: 2, m: 14, s: 33 });
  useEffect(() => {
    const t = setInterval(() => {
      setTime((p) => {
        let { h, m, s } = p;
        s -= 1;
        if (s < 0) { s = 59; m -= 1; }
        if (m < 0) { m = 59; h -= 1; }
        if (h < 0) { h = 2; m = 14; s = 33; }
        return { h, m, s };
      });
    }, 1000);
    return () => clearInterval(t);
  }, []);
  const pad = (n: number) => n.toString().padStart(2, "0");
  return (
    <section className="relative isolate overflow-hidden py-28">
      <div className="absolute inset-0 -z-10">
        <div
          className="absolute inset-0"
          style={{
            background: "radial-gradient(800px 500px at 30% 40%, rgba(100,181,246,0.30), transparent 60%), radial-gradient(700px 500px at 70% 60%, rgba(255,183,77,0.30), transparent 60%)",
          }}
        />
      </div>
      <div className="mx-auto max-w-4xl px-4 text-center sm:px-6">
        <motion.h2
          variants={reveal} initial="hidden" whileInView="show" viewport={{ once: true }}
          className="gradient-text font-display text-4xl font-extrabold leading-tight sm:text-6xl"
          style={{ filter: "drop-shadow(0 4px 32px rgba(100,181,246,0.25))" }}
        >
          Start Your A‑to‑Z Profit Journey Today
        </motion.h2>
        <motion.p variants={reveal} initial="hidden" whileInView="show" viewport={{ once: true }} custom={1} className="mx-auto mt-5 max-w-xl text-foreground/75 sm:text-lg">
          Join 50,000+ traders profiting on autopilot. 100% conversion guaranteed.
        </motion.p>
        <motion.div variants={reveal} initial="hidden" whileInView="show" viewport={{ once: true }} custom={2} className="mt-8 flex justify-center">
          <Link to="/products">
            <MagneticButton
              as="button"
              onClick={(e: React.MouseEvent) => spawnConfetti(e.clientX, e.clientY, true)}
              className="btn-primary btn-primary-pulse inline-flex items-center gap-2 rounded-2xl px-8 py-4 text-lg"
            >
              <Zap className="h-5 w-5" /> Get ARTRIX Now — Risk-Free 30 Days
            </MagneticButton>
          </Link>
        </motion.div>
        <p className="mt-4 text-xs text-foreground/60">No credit card needed · Cancel anytime · 30-day money-back guarantee</p>
        <div
          className="mt-6 inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm"
          style={{
            background: "rgba(255,183,77,0.10)",
            border: "1px solid rgba(255,183,77,0.30)",
            boxShadow: "0 0 20px -6px rgba(255,183,77,0.45)",
          }}
        >
          <span>⏰ Offer ends in</span>
          <span
            className="font-mono font-bold tabular-nums"
            style={{ color: "#ffb74d", textShadow: "0 0 8px rgba(255,183,77,0.6)" }}
          >
            {pad(time.h)}:{pad(time.m)}:{pad(time.s)}
          </span>
        </div>
      </div>
    </section>
  );
}

/* ---------------- CONTACT ---------------- */
export function Contact() {
  const [sent, setSent] = useState(false);
  return (
    <section id="contact" className="relative py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHeading eyebrow="Contact" title="Talk to the ARTRIX Team" subtitle="Sales, support, partnerships — we respond within the hour." />
        <div className="mt-14 grid gap-6 lg:grid-cols-5">
          <motion.form
            variants={reveal} initial="hidden" whileInView="show" viewport={{ once: true }}
            onSubmit={(e) => {
              e.preventDefault();
              setSent(true);
              spawnConfetti(window.innerWidth / 2, window.innerHeight / 2, true);
              setTimeout(() => setSent(false), 4000);
            }}
            className="glass-strong rounded-3xl p-6 sm:p-8 lg:col-span-3"
          >
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Name" />
              <Field label="Email" type="email" />
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold uppercase tracking-wider text-foreground/60">Subject</label>
                <select className="mt-2 w-full rounded-xl glass px-3 py-3 text-sm outline-none focus:ring-2 focus:ring-[rgba(100,181,246,0.5)]">
                  {["Sales", "Support", "Partnership", "Press"].map((o) => <option key={o} className="bg-[#14122e]">{o}</option>)}
                </select>
              </div>
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold uppercase tracking-wider text-foreground/60">Message</label>
                <textarea rows={5} className="mt-2 w-full rounded-xl glass px-3 py-3 text-sm outline-none focus:ring-2 focus:ring-[rgba(100,181,246,0.5)]" />
              </div>
            </div>
            <MagneticButton className="btn-primary mt-6 inline-flex items-center gap-2 rounded-xl px-6 py-3 text-sm">
              {sent ? <><Check className="h-4 w-4" /> Message Sent</> : <>Send Message <Send className="h-4 w-4" /></>}
            </MagneticButton>
          </motion.form>

          <motion.div variants={reveal} initial="hidden" whileInView="show" viewport={{ once: true }} custom={1} className="space-y-3 lg:col-span-2">
            <ContactCard icon={<Mail className="h-4 w-4" style={{ color: "#64b5f6", filter: "drop-shadow(0 0 4px rgba(100,181,246,0.5))" }} />} label="Email" value="support@artrixsoftware.com" />
            <ContactCard icon={<Phone className="h-4 w-4" style={{ color: "#64b5f6", filter: "drop-shadow(0 0 4px rgba(100,181,246,0.5))" }} />} label="Phone" value="+1 (800) ARTRIX-9" />
            <ContactCard icon={<MapPin className="h-4 w-4" style={{ color: "#64b5f6", filter: "drop-shadow(0 0 4px rgba(100,181,246,0.5))" }} />} label="HQ" value="Silicon Valley, California, USA" />
            <ContactCard icon={<MessageSquare className="h-4 w-4" style={{ color: "#64b5f6", filter: "drop-shadow(0 0 4px rgba(100,181,246,0.5))" }} />} label="Live Chat" value="Online · avg. reply 28s" online />

            <div className="glass mt-2 flex items-center justify-around rounded-2xl p-4">
              {[Twitter, Linkedin, Send, Youtube, Instagram].map((I, i) => (
                <a key={i} href="#" className="grid h-10 w-10 place-items-center rounded-xl glass transition hover:scale-110 hover:bg-white/10">
                  <I className="h-4 w-4" style={{ color: "#64b5f6", filter: "drop-shadow(0 0 4px rgba(100,181,246,0.5))" }} />
                </a>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
function Field({ label, type = "text" }: { label: string; type?: string }) {
  return (
    <div>
      <label className="block text-xs font-semibold uppercase tracking-wider text-foreground/60">{label}</label>
      <input type={type} className="mt-2 w-full rounded-xl glass px-3 py-3 text-sm outline-none transition focus:ring-2 focus:ring-[rgba(100,181,246,0.5)]" />
    </div>
  );
}
function ContactCard({ icon, label, value, online }: { icon: React.ReactNode; label: string; value: string; online?: boolean }) {
  return (
    <div className="glass flex items-center gap-3 rounded-2xl p-4">
      <div
        className="grid h-10 w-10 place-items-center rounded-xl ring-1"
        style={{
          background: "linear-gradient(135deg, rgba(100,181,246,0.18), rgba(186,104,200,0.18))",
          borderColor: "rgba(100,181,246,0.30)",
        }}
      >
        {icon}
      </div>
      <div className="min-w-0">
        <div className="text-[10px] font-semibold uppercase tracking-wider text-foreground/60">{label}</div>
        <div className="truncate text-sm font-semibold">{value}</div>
      </div>
      {online && (
        <span
          className="ml-auto inline-flex items-center gap-1 text-[10px] font-semibold"
          style={{ color: "#64b5f6", textShadow: "0 0 6px rgba(100,181,246,0.5)" }}
        >
          <span className="h-2 w-2 rounded-full bg-[#64b5f6]" style={{ boxShadow: "0 0 8px #64b5f6" }} /> Online
        </span>
      )}
    </div>
  );
}

/* ---------------- FOOTER ---------------- */
export function Footer() {
  return (
    <footer className="relative mt-10">
      <div
        className="h-[2px] w-full"
        style={{
          background: "linear-gradient(90deg, #64b5f6 0%, #ba68c8 50%, #ffb74d 100%)",
          backgroundSize: "200% 100%",
          animation: "gradient-shift 6s ease infinite",
          boxShadow: "0 0 14px rgba(100,181,246,0.45)",
        }}
      />
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-6">
        <div className="lg:col-span-2">
          <div className="flex items-center gap-2.5">
            <span className="relative grid h-9 w-9 place-items-center">
              <span className="absolute inset-0 rounded-full ring-conic blur-[1px]" style={{ animation: "ring-spin 8s linear infinite" }} />
              <span className="absolute inset-[2px] rounded-full bg-[#0d0420]" />
              <Sparkles className="relative h-4 w-4" style={{ color: "#64b5f6", filter: "drop-shadow(0 0 4px rgba(100,181,246,0.6))" }} />
            </span>
            <span className="gradient-text text-xl font-extrabold">ARTRIX</span>
          </div>
          <p className="mt-3 text-sm text-foreground/65">Profit on Autopilot. A to Z.</p>
          <p className="mt-2 text-xs text-foreground/55">Elite AI trading bots engineered by quants who left Wall Street to build the future of profit.</p>
          <div className="mt-4 flex gap-2">
            {[Twitter, Linkedin, Send, Youtube, Instagram].map((I, i) => (
              <a key={i} href="#" className="grid h-9 w-9 place-items-center rounded-xl glass hover:bg-white/10">
                <I className="h-4 w-4" style={{ color: "#64b5f6", filter: "drop-shadow(0 0 4px rgba(100,181,246,0.5))" }} />
              </a>
            ))}
          </div>
        </div>
        <div>
          <div className="text-xs font-bold uppercase tracking-[0.2em] text-foreground/70">Quick Links</div>
          <ul className="mt-3 space-y-1.5 text-sm">
            <li><Link to="/" className="text-foreground/70 hover:text-foreground transition">Home</Link></li>
            <li><Link to="/products" className="text-foreground/70 hover:text-foreground transition">Products</Link></li>
            <li><Link to="/faq" className="text-foreground/70 hover:text-foreground transition">About Us</Link></li>
            <li><Link to="/faq" className="text-foreground/70 hover:text-foreground transition">Developer History</Link></li>
            <li><Link to="/contact" className="text-foreground/70 hover:text-foreground transition">Contact Us</Link></li>
          </ul>
        </div>
        <div>
          <div className="text-xs font-bold uppercase tracking-[0.2em] text-foreground/70">Products</div>
          <ul className="mt-3 space-y-1.5 text-sm">
            <li><Link to="/products" className="text-foreground/70 hover:text-foreground transition">Starter</Link></li>
            <li><Link to="/products" className="text-foreground/70 hover:text-foreground transition">Pro</Link></li>
            <li><Link to="/products" className="text-foreground/70 hover:text-foreground transition">Elite</Link></li>
            <li><Link to="/products" className="text-foreground/70 hover:text-foreground transition">Institutional</Link></li>
            <li><Link to="/products" className="text-foreground/70 hover:text-foreground transition">API</Link></li>
            <li><Link to="/products" className="text-foreground/70 hover:text-foreground transition">Mobile App</Link></li>
          </ul>
        </div>
        <div>
          <div className="text-xs font-bold uppercase tracking-[0.2em] text-foreground/70">Resources</div>
          <ul className="mt-3 space-y-1.5 text-sm">
            <li><Link to="/faq" className="text-foreground/70 hover:text-foreground transition">Blog</Link></li>
            <li><Link to="/faq" className="text-foreground/70 hover:text-foreground transition">FAQ</Link></li>
            <li><Link to="/faq" className="text-foreground/70 hover:text-foreground transition">Documentation</Link></li>
            <li><Link to="/faq" className="text-foreground/70 hover:text-foreground transition">Trading Guides</Link></li>
            <li><Link to="/faq" className="text-foreground/70 hover:text-foreground transition">Market Analysis</Link></li>
          </ul>
        </div>
        <div>
          <div className="text-xs font-bold uppercase tracking-[0.2em] text-foreground/70">Newsletter</div>
          <p className="mt-3 text-xs text-foreground/60">Get profit tips weekly.</p>
          <form
            onSubmit={(e) => { e.preventDefault(); spawnConfetti(window.innerWidth - 40, window.innerHeight - 40); }}
            className="mt-3 flex gap-2"
          >
            <input type="email" placeholder="you@email.com" className="min-w-0 flex-1 rounded-xl glass px-3 py-2 text-xs outline-none focus:ring-2 focus:ring-[rgba(100,181,246,0.5)]" />
            <button className="btn-primary rounded-xl px-3 py-2 text-xs">Subscribe</button>
          </form>
          <ul className="mt-5 space-y-1.5 text-xs text-foreground/65">
            {["Privacy Policy", "Terms of Service", "Refund Policy", "Risk Disclosure", "Cookie Policy"].map((l) => (
              <li key={l}><a href="#" className="hover:text-foreground">{l}</a></li>
            ))}
          </ul>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="flex flex-wrap items-center justify-center gap-3 border-t border-white/5 py-6 text-[11px] font-semibold uppercase tracking-wider text-foreground/60">
          <Lock className="h-3.5 w-3.5" style={{ color: "#64b5f6", filter: "drop-shadow(0 0 4px rgba(100,181,246,0.6))" }} /> SSL Secured
          <span>•</span> PCI Compliant
          <span>•</span> SOC 2 Certified
          <span>•</span> Award Winner 2025
        </div>
        <div className="flex flex-wrap items-center justify-center gap-2 pb-4 text-[10px] text-foreground/55">
          {["Visa", "Mastercard", "Amex", "PayPal", "Crypto", "Apple Pay", "UPI"].map((p) => (
            <span key={p} className="glass rounded-md px-2 py-1">{p}</span>
          ))}
        </div>
        <p className="pb-4 text-center text-[11px] text-foreground/50">Trading involves risk. Past performance is not indicative of future results.</p>
        <p className="pb-8 text-center text-xs text-foreground/60">© 2026 ARTRIX SOFTWARE. All rights reserved. Built for the world.</p>
      </div>
    </footer>
  );
}
function FooterCol({ title, items }: { title: string; items: string[] }) {
  return (
    <div>
      <div className="text-xs font-bold uppercase tracking-[0.2em] text-foreground/70">{title}</div>
      <ul className="mt-3 space-y-1.5 text-sm">
        {items.map((i) => <li key={i}><a href="#" className="text-foreground/70 hover:text-foreground">{i}</a></li>)}
      </ul>
    </div>
  );
}

/* ---------------- Back to top ---------------- */
export function BackToTop() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const on = () => setShow(window.scrollY > 600);
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);
  if (!show) return null;
  return (
    <button
      aria-label="Back to top"
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      className="fixed bottom-6 left-6 z-40 grid h-12 w-12 place-items-center rounded-full btn-primary btn-primary-pulse"
    >
      <ArrowUp className="h-5 w-5" />
    </button>
  );
}

/* ---------------- Confetti ---------------- */
function spawnConfetti(x: number, y: number, big = false) {
  const colors = ["#64b5f6", "#ba68c8", "#ffb74d", "#ffd180", "#c9a8db"];
  const n = big ? 60 : 28;
  for (let i = 0; i < n; i++) {
    const el = document.createElement("span");
    const size = 4 + Math.random() * (big ? 8 : 5);
    Object.assign(el.style, {
      position: "fixed", left: `${x}px`, top: `${y}px`,
      width: `${size}px`, height: `${size}px`,
      background: colors[i % colors.length],
      borderRadius: "2px",
      pointerEvents: "none", zIndex: "9999",
      transform: "translate(-50%,-50%)",
      boxShadow: `0 0 8px ${colors[i % colors.length]}`,
    } as CSSStyleDeclaration);
    document.body.appendChild(el);
    const angle = Math.random() * Math.PI * 2;
    const speed = 80 + Math.random() * (big ? 280 : 160);
    const dx = Math.cos(angle) * speed;
    const dy = Math.sin(angle) * speed - 80;
    el.animate(
      [
        { transform: "translate(-50%,-50%) rotate(0deg)", opacity: 1 },
        { transform: `translate(calc(-50% + ${dx}px), calc(-50% + ${dy + 240}px)) rotate(${720 * (Math.random() - 0.5)}deg)`, opacity: 0 },
      ],
      { duration: 1200 + Math.random() * 400, easing: "cubic-bezier(.16,1,.3,1)" }
    ).onfinish = () => el.remove();
  }
}

/* ---------------- Sticky mobile CTA ---------------- */
export function MobileStickyCTA() {
  return (
    <div className="fixed inset-x-3 bottom-3 z-40 md:hidden">
      <Link to="/products" className="btn-primary btn-primary-pulse flex items-center justify-center gap-2 rounded-2xl px-4 py-3 text-sm font-bold">
        See Products →
      </Link>
    </div>
  );
}

/* ---------------- ROOT ---------------- */
export default function Site() {
  const [booting, setBooting] = useState(true);
  return (
    <div className="relative isolate min-h-screen overflow-x-clip">
      <MovingAnimatedBackground />
      {booting && <Boot onDone={() => setBooting(false)} />}
      <Navbar />
      <ProgressRing />
      <main className="relative z-10">
        <Hero />
        <StatsMarquee />
        <Shop />
        <Features />
        <LiveDemo />
        <About />
        <Timeline />
        <Testimonials />
        <FinalCTA />
        <Contact />
      </main>
      <Footer />
      <BackToTop />
      <MobileStickyCTA />
    </div>
  );
}
