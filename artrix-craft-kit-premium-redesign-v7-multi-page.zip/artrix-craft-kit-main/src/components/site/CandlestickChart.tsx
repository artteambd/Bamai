import { useEffect, useState } from "react";

/**
 * Premium candlestick chart — sophisticated institutional look.
 * Soft azure up-candles with subtle glow, warm amber accents on highs,
 * soft crimson down-candles. Animated price line with azure → orchid → amber
 * gradient and glow trail. Pulsing live price dot with expanding ping ring.
 * Floating ±$ profit badges in azure/amber with glow shadows.
 * "LIVE · QUOTEX" style label in corner with blinking dot.
 */
export function CandlestickChart() {
  const total = 32;
  const [n, setN] = useState(0);
  const [badges, setBadges] = useState<{ id: number; x: number; y: number; v: number; color: string }[]>([]);

  // Seedable wave so each render is identical — uptrend bias
  const candles = Array.from({ length: total }, (_, i) => {
    const base = 50 + Math.sin(i * 0.45) * 14 + Math.cos(i * 0.23) * 6 + (i * 0.4);
    const open = base + (i % 3 === 0 ? -2 : 2);
    const close = base + (i % 2 === 0 ? 4 : -3) + (i > 18 ? 6 : 0);
    const high = Math.max(open, close) + 2 + (i % 4);
    const low = Math.min(open, close) - 2 - (i % 5);
    return { open, close, high, low };
  });

  useEffect(() => {
    if (n >= total) return;
    const t = setTimeout(() => setN((v) => v + 1), 80);
    return () => clearTimeout(t);
  }, [n]);

  useEffect(() => {
    let id = 0;
    const int = setInterval(() => {
      id += 1;
      const isWin = Math.random() > 0.25;
      setBadges((b) => [
        ...b.slice(-4),
        {
          id,
          x: 30 + Math.random() * 260,
          y: 20 + Math.random() * 70,
          v: Math.floor(80 + Math.random() * 1200),
          color: isWin ? "#64b5f6" : "#ff5252",
        },
      ]);
    }, 1400);
    return () => clearInterval(int);
  }, []);

  const W = 360, H = 180;
  const cw = W / total;

  const pricePath = candles
    .slice(0, n)
    .map((c, i) => `${i === 0 ? "M" : "L"} ${i * cw + cw / 2} ${H - c.close * 1.6}`)
    .join(" ");

  return (
    <div className="relative h-full w-full">
      <svg viewBox={`0 0 ${W} ${H}`} className="h-full w-full" preserveAspectRatio="none">
        <defs>
          {/* Azure up-candle gradient */}
          <linearGradient id="candleUpGrad" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0" stopColor="#64b5f6" />
            <stop offset="1" stopColor="#1976d2" />
          </linearGradient>
          {/* Crimson down-candle gradient */}
          <linearGradient id="candleDownGrad" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0" stopColor="#ff5252" />
            <stop offset="1" stopColor="#c62828" />
          </linearGradient>
          {/* Price line gradient — azure → orchid → amber */}
          <linearGradient id="lineGrad" x1="0" x2="1">
            <stop offset="0" stopColor="#64b5f6" />
            <stop offset="0.5" stopColor="#ba68c8" />
            <stop offset="1" stopColor="#ffb74d" />
          </linearGradient>
          {/* Area fill under price line */}
          <linearGradient id="areaGrad" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0" stopColor="#64b5f6" stopOpacity="0.32" />
            <stop offset="0.7" stopColor="#ba68c8" stopOpacity="0.08" />
            <stop offset="1" stopColor="#64b5f6" stopOpacity="0" />
          </linearGradient>
          {/* Glow filters */}
          <filter id="candleGlowUp" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="1.8" result="b" />
            <feMerge>
              <feMergeNode in="b" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
          <filter id="candleGlowDown" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="1.4" result="b" />
            <feMerge>
              <feMergeNode in="b" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
          <filter id="lineGlow" x="-20%" y="-50%" width="140%" height="200%">
            <feGaussianBlur stdDeviation="2.2" result="b" />
            <feMerge>
              <feMergeNode in="b" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
          <filter id="dotGlow" x="-100%" y="-100%" width="300%" height="300%">
            <feGaussianBlur stdDeviation="2.8" result="b" />
            <feMerge>
              <feMergeNode in="b" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Subtle horizontal grid lines */}
        {[0, 1, 2, 3, 4].map((i) => (
          <line
            key={i}
            x1="0" x2={W}
            y1={(i + 1) * (H / 6)} y2={(i + 1) * (H / 6)}
            stroke="rgba(186, 104, 200, 0.06)"
            strokeDasharray="2 4"
          />
        ))}

        {/* Candles */}
        {candles.slice(0, n).map((c, i) => {
          const up = c.close >= c.open;
          const cx = i * cw + cw / 2;
          const top = H - Math.max(c.open, c.close) * 1.6;
          const bot = H - Math.min(c.open, c.close) * 1.6;
          const color = up ? "#64b5f6" : "#ff5252";
          const gradId = up ? "candleUpGrad" : "candleDownGrad";
          const glowId = up ? "candleGlowUp" : "candleGlowDown";
          return (
            <g key={i} style={{ animation: `candle-breathe ${2 + (i % 3) * 0.4}s ease-in-out infinite`, animationDelay: `${i * 0.05}s`, color }}>
              {/* Wick line */}
              <line
                x1={cx} x2={cx}
                y1={H - c.high * 1.6} y2={H - c.low * 1.6}
                stroke={color}
                strokeWidth="1.2"
                opacity="0.85"
                filter={`url(#${glowId})`}
              />
              {/* Body */}
              <rect
                x={cx - cw * 0.36}
                y={top}
                width={cw * 0.72}
                height={Math.max(2, bot - top)}
                fill={`url(#${gradId})`}
                opacity="0.95"
                rx="1.5"
                filter={`url(#${glowId})`}
              />
              {/* Inner highlight */}
              <rect
                x={cx - cw * 0.36}
                y={top}
                width={cw * 0.72}
                height={Math.max(1, (bot - top) * 0.35)}
                fill="rgba(255,255,255,0.30)"
                rx="1.5"
              />
            </g>
          );
        })}

        {/* Price line + area under */}
        {n > 1 && (
          <>
            <path
              d={`${pricePath} L ${(n - 1) * cw + cw / 2} ${H} L ${cw / 2} ${H} Z`}
              fill="url(#areaGrad)"
            />
            <path
              d={pricePath}
              fill="none"
              stroke="url(#lineGrad)"
              strokeWidth="2.4"
              strokeLinejoin="round"
              strokeLinecap="round"
              filter="url(#lineGlow)"
            />
            {/* Live price pulsing dot */}
            <circle
              cx={(n - 1) * cw + cw / 2}
              cy={H - candles[n - 1].close * 1.6}
              r="4"
              fill="#64b5f6"
              filter="url(#dotGlow)"
            >
              <animate attributeName="r" values="3.5;6;3.5" dur="1.4s" repeatCount="indefinite" />
              <animate attributeName="opacity" values="1;0.7;1" dur="1.4s" repeatCount="indefinite" />
            </circle>
            {/* Outer ping ring */}
            <circle
              cx={(n - 1) * cw + cw / 2}
              cy={H - candles[n - 1].close * 1.6}
              r="4"
              fill="none"
              stroke="#64b5f6"
              strokeWidth="1.2"
              opacity="0.6"
            >
              <animate attributeName="r" values="4;14;4" dur="1.8s" repeatCount="indefinite" />
              <animate attributeName="opacity" values="0.7;0;0.7" dur="1.8s" repeatCount="indefinite" />
            </circle>
          </>
        )}

        {/* LIVE label badge in top-left — like "LIVE · QUOTEX" */}
        <g>
          <rect x="6" y="6" width="68" height="16" rx="4" fill="rgba(100, 181, 246, 0.14)" stroke="rgba(100, 181, 246, 0.45)" strokeWidth="0.5" />
          <circle cx="14" cy="14" r="2.5" fill="#64b5f6">
            <animate attributeName="opacity" values="1;0.3;1" dur="1s" repeatCount="indefinite" />
          </circle>
          <text x="20" y="17" fontSize="9" fontWeight="700" fill="#64b5f6" fontFamily="JetBrains Mono, monospace" letterSpacing="0.8">LIVE</text>
          <text x="42" y="17" fontSize="8" fontWeight="500" fill="#ba68c8" fontFamily="JetBrains Mono, monospace" letterSpacing="0.5">· M1</text>
        </g>

        {/* Pair label in top-right */}
        <text x={W - 6} y="17" fontSize="9" fontWeight="600" fill="rgba(247, 245, 255, 0.55)" fontFamily="JetBrains Mono, monospace" textAnchor="end" letterSpacing="0.5">NZD/USD</text>
      </svg>

      {/* Floating profit badges */}
      {badges.map((b) => (
        <span
          key={b.id}
          className="pointer-events-none absolute text-xs font-bold font-mono"
          style={{
            left: `${(b.x / W) * 100}%`,
            top: `${(b.y / H) * 100}%`,
            color: b.color,
            textShadow: `0 0 12px ${b.color}cc, 0 0 24px ${b.color}66`,
            animation: "scroll-bounce 2.6s ease-out forwards",
          }}
        >
          {b.color === "#64b5f6" ? "+" : "−"}${b.v}
        </span>
      ))}
    </div>
  );
}
