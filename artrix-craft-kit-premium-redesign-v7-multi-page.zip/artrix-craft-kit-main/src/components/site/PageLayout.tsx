import { useState } from "react";
import { Navbar } from "./Navbar";
import { Footer, ProgressRing, BackToTop, MobileStickyCTA, Boot } from "./Site";
import { MovingAnimatedBackground } from "./MovingAnimatedBackground";

/**
 * PageLayout — shared shell for every routed page.
 * Includes: MovingAnimatedBackground + Navbar + page content + Footer + ProgressRing + BackToTop + MobileStickyCTA + Boot sequence.
 */
export function PageLayout({ children, boot = true }: { children: React.ReactNode; boot?: boolean }) {
  const [booting, setBooting] = useState(boot);

  return (
    <div className="relative isolate min-h-screen overflow-x-clip">
      <MovingAnimatedBackground />
      {booting && <Boot onDone={() => setBooting(false)} />}
      <Navbar />
      <ProgressRing />
      <main className="relative z-10">
        {children}
      </main>
      <Footer />
      <BackToTop />
      <MobileStickyCTA />
    </div>
  );
}
