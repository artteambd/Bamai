/**
 * HeroAurora — cinematic animated background for the hero.
 * Sophisticated institutional palette: deep purple → indigo cosmic base,
 * azure blue + orchid purple + amber gold aurora swirls, crepuscular gold rays,
 * pulsing core. Pure CSS/SVG, GPU-friendly, respects prefers-reduced-motion.
 */
export function HeroAurora() {
  return (
    <div
      aria-hidden
      className="pointer-events-none absolute inset-0 -z-10 overflow-hidden"
      style={{
        background:
          "radial-gradient(120% 80% at 50% 10%, #1A0033 0%, #0F172A 55%, #050810 100%)",
      }}
    >
      {/* Starfield */}
      <div className="hero-stars absolute inset-0 opacity-70" />
      <div className="hero-stars hero-stars--slow absolute inset-0 opacity-50" />

      {/* Aurora swirl (two counter-rotating conic gradients — azure/orchid/amber) */}
      <div className="absolute left-1/2 top-1/2 h-[140vmax] w-[140vmax] -translate-x-1/2 -translate-y-1/2">
        <div
          className="hero-swirl absolute inset-0 rounded-full opacity-[0.55] mix-blend-screen"
          style={{
            background:
              "conic-gradient(from 0deg, rgba(100,181,246,0) 0%, rgba(100,181,246,0.55) 18%, rgba(186,104,200,0.55) 35%, rgba(255,183,77,0.45) 52%, rgba(255,209,128,0.35) 68%, rgba(100,181,246,0) 85%, rgba(100,181,246,0) 100%)",
            filter: "blur(60px)",
          }}
        />
        <div
          className="hero-swirl-reverse absolute inset-0 rounded-full opacity-40 mix-blend-screen"
          style={{
            background:
              "conic-gradient(from 180deg, rgba(100,181,246,0) 0%, rgba(186,104,200,0.5) 25%, rgba(100,181,246,0.5) 50%, rgba(255,183,77,0.3) 75%, rgba(100,181,246,0) 100%)",
            filter: "blur(80px)",
          }}
        />
      </div>

      {/* Crepuscular light burst rays (amber-tinged) */}
      <div
        className="hero-rays absolute left-1/2 top-[55%] h-[120vmax] w-[120vmax] -translate-x-1/2 -translate-y-1/2 opacity-[0.30] mix-blend-screen"
        style={{
          background:
            "repeating-conic-gradient(from 0deg at 50% 50%, rgba(255,220,160,0) 0deg, rgba(255,220,160,0.50) 1.2deg, rgba(255,220,160,0) 5deg)",
          maskImage:
            "radial-gradient(circle at 50% 50%, rgba(0,0,0,1) 0%, rgba(0,0,0,0.9) 25%, rgba(0,0,0,0) 70%)",
          WebkitMaskImage:
            "radial-gradient(circle at 50% 50%, rgba(0,0,0,1) 0%, rgba(0,0,0,0.9) 25%, rgba(0,0,0,0) 70%)",
        }}
      />

      {/* Core light burst — azure with orchid halo */}
      <div
        className="hero-pulse absolute left-1/2 top-[58%] h-[60vmax] w-[60vmax] -translate-x-1/2 -translate-y-1/2 rounded-full mix-blend-screen"
        style={{
          background:
            "radial-gradient(circle, rgba(100,181,246,0.55) 0%, rgba(186,104,200,0.35) 18%, rgba(255,183,77,0.18) 40%, rgba(0,0,0,0) 70%)",
          filter: "blur(20px)",
        }}
      />

      {/* Drifting nebula blobs — azure + orchid + amber */}
      <div className="hero-blob-a absolute -left-32 top-10 h-[55vmax] w-[55vmax] rounded-full opacity-50 mix-blend-screen"
        style={{ background: "radial-gradient(circle, rgba(100,181,246,0.45), rgba(0,0,0,0) 65%)", filter: "blur(80px)" }} />
      <div className="hero-blob-b absolute -right-40 bottom-0 h-[60vmax] w-[60vmax] rounded-full opacity-50 mix-blend-screen"
        style={{ background: "radial-gradient(circle, rgba(186,104,200,0.45), rgba(0,0,0,0) 65%)", filter: "blur(90px)" }} />
      {/* Amber accent blob */}
      <div className="hero-blob-c absolute right-[20%] top-[15%] h-[35vmax] w-[35vmax] rounded-full opacity-30 mix-blend-screen"
        style={{ background: "radial-gradient(circle, rgba(255,183,77,0.40), rgba(0,0,0,0) 65%)", filter: "blur(80px)" }} />

      {/* Top + bottom vignette */}
      <div className="absolute inset-x-0 top-0 h-40 bg-gradient-to-b from-[#050810] to-transparent" />
      <div className="absolute inset-x-0 bottom-0 h-48 bg-gradient-to-t from-[#050810] to-transparent" />

      <style>{`
        @keyframes heroSwirl {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        @keyframes heroSwirlReverse {
          from { transform: rotate(360deg); }
          to { transform: rotate(0deg); }
        }
        @keyframes heroRays {
          from { transform: translate(-50%, -50%) rotate(0deg); }
          to { transform: translate(-50%, -50%) rotate(360deg); }
        }
        @keyframes heroPulse {
          0%, 100% { transform: translate(-50%, -50%) scale(1); opacity: 0.85; }
          50%      { transform: translate(-50%, -50%) scale(1.12); opacity: 1; }
        }
        @keyframes heroBlobA {
          0%, 100% { transform: translate(0,0) scale(1); }
          50%      { transform: translate(60px, -40px) scale(1.1); }
        }
        @keyframes heroBlobB {
          0%, 100% { transform: translate(0,0) scale(1); }
          50%      { transform: translate(-50px, 30px) scale(1.08); }
        }
        @keyframes heroBlobC {
          0%, 100% { transform: translate(0,0) scale(1); }
          50%      { transform: translate(40px, 60px) scale(1.05); }
        }
        @keyframes heroStars {
          from { transform: translateY(0); }
          to   { transform: translateY(-200px); }
        }
        .hero-swirl         { animation: heroSwirl 60s linear infinite; }
        .hero-swirl-reverse { animation: heroSwirlReverse 90s linear infinite; }
        .hero-rays          { animation: heroRays 140s linear infinite; transform-origin: 50% 50%; }
        .hero-pulse         { animation: heroPulse 5.5s ease-in-out infinite; }
        .hero-blob-a        { animation: heroBlobA 18s ease-in-out infinite; }
        .hero-blob-b        { animation: heroBlobB 22s ease-in-out infinite; }
        .hero-blob-c        { animation: heroBlobC 26s ease-in-out infinite; }
        .hero-stars {
          background-image:
            radial-gradient(1px 1px at 20px 30px, #fff, transparent),
            radial-gradient(1px 1px at 70px 120px, rgba(100,181,246,0.85), transparent),
            radial-gradient(1.5px 1.5px at 160px 60px, #fff, transparent),
            radial-gradient(1px 1px at 220px 200px, rgba(255,183,77,0.8), transparent),
            radial-gradient(1px 1px at 300px 100px, #fff, transparent),
            radial-gradient(1.5px 1.5px at 380px 260px, rgba(186,104,200,0.9), transparent),
            radial-gradient(1px 1px at 90px 280px, rgba(255,255,255,0.6), transparent);
          background-size: 400px 320px;
          animation: heroStars 80s linear infinite;
        }
        .hero-stars--slow { background-size: 600px 480px; animation-duration: 160s; }
        @media (prefers-reduced-motion: reduce) {
          .hero-swirl, .hero-swirl-reverse, .hero-rays, .hero-pulse,
          .hero-blob-a, .hero-blob-b, .hero-blob-c, .hero-stars { animation: none !important; }
        }
      `}</style>
    </div>
  );
}
