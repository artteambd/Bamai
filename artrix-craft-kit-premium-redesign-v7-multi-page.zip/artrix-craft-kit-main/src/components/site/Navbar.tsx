import { useEffect, useState } from "react";
import { Link, useRouter } from "@tanstack/react-router";
import { motion, AnimatePresence, useScroll, useSpring } from "framer-motion";
import { Menu, X, Sparkles, Crown, User, ChevronRight, ShoppingBag } from "lucide-react";
import { MagneticButton } from "./Primitives";

const links = [
  { label: "Home", to: "/" },
  { label: "Products", to: "/products" },
  { label: "Reviews", to: "/reviews" },
  { label: "FAQ", to: "/faq" },
  { label: "Support", to: "/support" },
  { label: "Contact", to: "/contact" },
];

export function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { scrollYProgress } = useScroll();
  const sx = useSpring(scrollYProgress, { stiffness: 120, damping: 20 });

  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 24);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);

  return (
    <>
      {/* Premium scroll progress bar — azure → orchid → amber */}
      <motion.div
        style={{ scaleX: sx }}
        className="fixed left-0 right-0 top-0 z-[60] h-[3px] origin-left"
      >
        <div className="h-full w-full" style={{
          background: "linear-gradient(90deg, #64b5f6 0%, #ba68c8 50%, #ffb74d 100%)",
          boxShadow: "0 0 14px rgba(100, 181, 246, 0.75), 0 0 28px rgba(186, 104, 200, 0.45)",
        }} />
      </motion.div>

      <header
        className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
          scrolled ? "py-2" : "py-4"
        }`}
      >
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div
            className={`glass flex items-center justify-between rounded-2xl px-4 py-3 transition-all duration-500 ${
              scrolled ? "backdrop-blur-2xl" : ""
            }`}
            style={{ borderColor: "rgba(186, 104, 200, 0.28)" }}
          >
            {/* Logo — premium orchid "A" mark */}
            <Link to="/" className="group flex items-center gap-2.5">
              <span className="relative grid h-10 w-10 place-items-center">
                {/* Animated gradient ring */}
                <span
                  className="absolute inset-0 rounded-xl ring-conic-azure opacity-90 blur-[1px]"
                  style={{ animation: "ring-spin 10s linear infinite" }}
                />
                <span className="absolute inset-[2px] rounded-[10px] bg-[#0F172A]" />
                <span
                  className="relative font-display text-xl font-extrabold"
                  style={{
                    color: "#B39DDB",
                    fontWeight: 700,
                  }}
                >
                  A
                </span>
              </span>
              <span className="flex flex-col leading-none">
                <span
                  className="text-xl font-extrabold tracking-tight font-display"
                  style={{
                    color: "#B39DDB",
                    fontWeight: 700,
                    letterSpacing: "0.05em",
                  }}
                >
                  ARTRIX
                </span>
                <span
                  className="text-[9px] font-semibold uppercase tracking-[0.25em] mt-0.5"
                  style={{ color: "#E0E0E0" }}
                >
                  Signal Intelligence
                </span>
              </span>
            </Link>

            {/* Desktop nav */}
            <nav className="hidden items-center gap-1 lg:flex">
              {links.slice(0, 5).map((l) => (
                <Link
                  key={l.label}
                  to={l.to}
                  className="group relative rounded-lg px-3 py-2 text-sm font-medium text-foreground/85 transition-colors hover:text-foreground"
                  activeProps={{ style: { color: "#00BFA5" } }}
                >
                  {l.label}
                  <span
                    className="absolute inset-x-3 -bottom-0.5 h-[2px] origin-left scale-x-0 rounded-full transition-transform duration-300 group-hover:scale-x-100"
                    style={{
                      background: "linear-gradient(90deg, #64b5f6, #ba68c8)",
                      boxShadow: "0 0 8px rgba(100, 181, 246, 0.7)",
                    }}
                  />
                </Link>
              ))}
            </nav>

            {/* Premium CTA buttons — Cart + Sign In (dark) + See Products (white) */}
            <div className="hidden md:flex items-center gap-2">
              {/* Cart icon */}
              <Link
                to="/products"
                aria-label="Cart"
                className="relative grid h-10 w-10 place-items-center rounded-xl glass transition hover:bg-white/10"
              >
                <ShoppingBag className="h-4 w-4" style={{ color: "#00BFA5" }} />
              </Link>
              <Link
                to="/contact"
                className="btn-secondary inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm"
              >
                <User className="h-4 w-4" />
                Sign In
              </Link>
              <Link
                to="/products"
                className="btn-primary btn-primary-pulse inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm"
              >
                See Products <span style={{ fontSize: "1.1em" }}>→</span>
              </Link>
            </div>

            {/* Mobile toggle */}
            <button
              aria-label="Toggle menu"
              onClick={() => setOpen((v) => !v)}
              className="grid h-10 w-10 place-items-center rounded-xl glass md:hidden"
            >
              <AnimatePresence mode="wait" initial={false}>
                {open ? (
                  <motion.span key="x" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }}>
                    <X className="h-5 w-5" />
                  </motion.span>
                ) : (
                  <motion.span key="m" initial={{ rotate: 90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: -90, opacity: 0 }}>
                    <Menu className="h-5 w-5" />
                  </motion.span>
                )}
              </AnimatePresence>
            </button>
          </div>
        </div>
      </header>

      {/* Mobile menu — like reference: links with right chevrons + Buy Now button */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 md:hidden"
          >
            <div className="absolute inset-0 bg-[#050810]/90 backdrop-blur-xl" onClick={() => setOpen(false)} />
            <motion.nav
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 24, stiffness: 220 }}
              className="absolute right-0 top-0 h-full w-[82%] max-w-sm flex flex-col p-6 pt-24"
              style={{
                background: "linear-gradient(180deg, #1A0033 0%, #0F172A 100%)",
                borderLeft: "1px solid rgba(0, 191, 165, 0.25)",
              }}
            >
              {/* Menu header */}
              <div
                className="mb-6 flex items-center justify-between rounded-2xl px-4 py-3"
                style={{
                  background: "rgba(255, 255, 255, 0.04)",
                  border: "1px solid rgba(255, 255, 255, 0.10)",
                }}
              >
                <div className="flex items-center gap-2">
                  <span
                    className="font-display text-lg font-extrabold"
                    style={{ color: "#B39DDB", letterSpacing: "0.05em" }}
                  >
                    ARTRIX
                  </span>
                  <span className="text-sm font-medium text-foreground/60">SOFTWARE</span>
                </div>
                <button
                  aria-label="Close menu"
                  onClick={() => setOpen(false)}
                  className="grid h-8 w-8 place-items-center rounded-lg glass"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {/* Links with right chevron arrows — like reference */}
              <ul className="flex-1 space-y-1">
                {links.map((l, i) => (
                  <motion.li
                    key={l.label}
                    initial={{ x: 30, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.05 + i * 0.06 }}
                  >
                    <Link
                      to={l.to}
                      onClick={() => setOpen(false)}
                      className="group flex items-center justify-between rounded-xl px-4 py-3.5 text-base font-medium text-foreground/90 transition hover:bg-white/5"
                      style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}
                    >
                      <span>{l.label}</span>
                      <ChevronRight
                        className="h-4 w-4 text-foreground/40 transition group-hover:translate-x-1 group-hover:text-[#00BFA5]"
                      />
                    </Link>
                  </motion.li>
                ))}
              </ul>

              {/* Buy Now button — full width at bottom (like reference) */}
              <Link
                to="/products"
                onClick={() => setOpen(false)}
                className="btn-primary btn-primary-pulse mt-4 block rounded-2xl px-4 py-4 text-center text-base font-bold"
              >
                Buy Now <span style={{ fontSize: "1.2em" }}>→</span>
              </Link>
            </motion.nav>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
