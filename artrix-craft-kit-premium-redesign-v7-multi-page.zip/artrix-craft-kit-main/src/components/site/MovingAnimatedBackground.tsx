import { useEffect, useRef } from "react";

/**
 * MovingAnimatedBackground — LIVE moving background (NOT static).
 *
 * Layers:
 * 1. Deep purple → dark blue → black vertical gradient base (EXACT reference)
 * 2. Drifting nebula blobs (slow movement, deep purple + teal + royal violet)
 * 3. Animated trading line chart that scrolls right-to-left continuously
 *    (mimics live market data movement)
 * 4. Floating particle network (connected dots that drift)
 * 5. Subtle moving grid (slow vertical scroll)
 * 6. Twinkling stars
 *
 * Pure canvas + CSS, GPU-friendly, respects prefers-reduced-motion.
 */
export function MovingAnimatedBackground() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d", { alpha: true });
    if (!ctx) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    let w = 0, h = 0;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    // === Particle network ===
    type P = { x: number; y: number; vx: number; vy: number; r: number; c: string };
    const colors = ["#00BFA5", "#9D5BFF", "#FFD700", "#81D4FA"];
    const ps: P[] = [];

    // === Scrolling trading line points ===
    type Pt = { x: number; y: number };
    let linePts: Pt[] = [];
    let lineOffset = 0;

    // === Stars ===
    type Star = { x: number; y: number; r: number; tw: number; ph: number };
    let stars: Star[] = [];

    const resize = () => {
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      canvas.style.width = w + "px";
      canvas.style.height = h + "px";
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      // Init particles
      const count = reduced ? 30 : Math.min(80, Math.floor((w * h) / 18000));
      ps.length = 0;
      for (let i = 0; i < count; i++) {
        ps.push({
          x: Math.random() * w,
          y: Math.random() * h,
          vx: (Math.random() - 0.5) * 0.25,
          vy: (Math.random() - 0.5) * 0.25,
          r: Math.random() * 1.6 + 0.5,
          c: colors[Math.floor(Math.random() * colors.length)],
        });
      }

      // Init stars
      const starCount = reduced ? 40 : 120;
      stars = Array.from({ length: starCount }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        r: Math.random() * 1.2 + 0.3,
        tw: Math.random() * 0.5 + 0.2,
        ph: Math.random() * Math.PI * 2,
      }));

      // Init trading line — full width wave
      linePts = [];
      const step = 12;
      for (let x = -step; x <= w + step; x += step) {
        const baseY = h * 0.55;
        const y = baseY + Math.sin(x * 0.008) * 60 + Math.cos(x * 0.015) * 35 + Math.sin(x * 0.003) * 90;
        linePts.push({ x, y });
      }
    };
    resize();
    window.addEventListener("resize", resize);

    let raf = 0;
    let t = 0;
    const tick = () => {
      t += 0.016;
      ctx.clearRect(0, 0, w, h);

      // === 1. Twinkling stars ===
      for (const s of stars) {
        const alpha = 0.4 + Math.sin(t * s.tw * 2 + s.ph) * 0.3;
        ctx.fillStyle = `rgba(255, 255, 255, ${alpha})`;
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fill();
      }

      // === 2. Moving particle network ===
      for (let i = 0; i < ps.length; i++) {
        const p = ps[i];
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < -10) p.x = w + 10;
        if (p.x > w + 10) p.x = -10;
        if (p.y < -10) p.y = h + 10;
        if (p.y > h + 10) p.y = -10;

        // glow dot
        const grd = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 5);
        grd.addColorStop(0, p.c + "cc");
        grd.addColorStop(1, p.c + "00");
        ctx.fillStyle = grd;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r * 5, 0, Math.PI * 2);
        ctx.fill();
      }
      // connecting lines
      for (let i = 0; i < ps.length; i++) {
        for (let j = i + 1; j < ps.length; j++) {
          const a = ps[i], b = ps[j];
          const dx = a.x - b.x, dy = a.y - b.y;
          const d2 = dx * dx + dy * dy;
          if (d2 < 14000) {
            const alpha = (1 - d2 / 14000) * 0.15;
            ctx.strokeStyle = `rgba(0, 191, 165, ${alpha})`;
            ctx.lineWidth = 0.6;
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.stroke();
          }
        }
      }

      // === 3. Scrolling trading line chart (moves right to left) ===
      lineOffset += 1.2;
      if (lineOffset > 24) {
        lineOffset = 0;
        // shift all points left by one step
        linePts = linePts.map((p) => ({ x: p.x - 12, y: p.y }));
        // add new point on the right
        const last = linePts[linePts.length - 1];
        const baseY = h * 0.55;
        const newX = last.x + 12;
        const newY = baseY + Math.sin((newX + t * 50) * 0.008) * 60 + Math.cos((newX + t * 30) * 0.015) * 35 + Math.sin((newX + t * 20) * 0.003) * 90;
        linePts.push({ x: newX, y: newY });
        // remove off-screen left point
        if (linePts[0].x < -24) linePts.shift();
      }

      // Draw glow area under line
      if (linePts.length > 1) {
        const areaGrad = ctx.createLinearGradient(0, h * 0.3, 0, h);
        areaGrad.addColorStop(0, "rgba(0, 191, 165, 0.18)");
        areaGrad.addColorStop(0.7, "rgba(157, 91, 255, 0.05)");
        areaGrad.addColorStop(1, "rgba(0, 191, 165, 0)");
        ctx.fillStyle = areaGrad;
        ctx.beginPath();
        ctx.moveTo(linePts[0].x, h);
        for (const p of linePts) ctx.lineTo(p.x, p.y);
        ctx.lineTo(linePts[linePts.length - 1].x, h);
        ctx.closePath();
        ctx.fill();

        // Draw the line itself with gradient + glow
        const lineGrad = ctx.createLinearGradient(0, 0, w, 0);
        lineGrad.addColorStop(0, "#00BFA5");
        lineGrad.addColorStop(0.5, "#9D5BFF");
        lineGrad.addColorStop(1, "#FFD700");

        ctx.strokeStyle = lineGrad;
        ctx.lineWidth = 2;
        ctx.shadowColor = "rgba(0, 191, 165, 0.7)";
        ctx.shadowBlur = 12;
        ctx.beginPath();
        ctx.moveTo(linePts[0].x, linePts[0].y);
        for (let i = 1; i < linePts.length; i++) {
          ctx.lineTo(linePts[i].x, linePts[i].y);
        }
        ctx.stroke();
        ctx.shadowBlur = 0;

        // Live price dot at the right edge
        const last = linePts[linePts.length - 1];
        if (last.x < w + 20) {
          ctx.fillStyle = "#FFD700";
          ctx.shadowColor = "#FFD700";
          ctx.shadowBlur = 16;
          ctx.beginPath();
          ctx.arc(last.x, last.y, 4, 0, Math.PI * 2);
          ctx.fill();
          ctx.shadowBlur = 0;

          // ping ring
          const pingR = 4 + (Math.sin(t * 3) * 0.5 + 0.5) * 14;
          const pingA = 1 - (Math.sin(t * 3) * 0.5 + 0.5);
          ctx.strokeStyle = `rgba(255, 215, 0, ${pingA})`;
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.arc(last.x, last.y, pingR, 0, Math.PI * 2);
          ctx.stroke();
        }
      }

      raf = requestAnimationFrame(tick);
    };
    if (!reduced) {
      raf = requestAnimationFrame(tick);
    } else {
      // static frame for reduced motion
      tick();
    }

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return (
    <div
      aria-hidden
      className="pointer-events-none fixed inset-0 -z-10 overflow-hidden"
      style={{
        background:
          "linear-gradient(180deg, #1A0033 0%, #0F172A 50%, #050810 100%)",
      }}
    >
      {/* Drifting nebula blobs (CSS animation — slow movement) */}
      <div
        className="absolute rounded-full"
        style={{
          width: "60vw",
          height: "60vw",
          left: "-15vw",
          top: "-10vw",
          background: "radial-gradient(circle, rgba(157, 91, 255, 0.28), transparent 65%)",
          filter: "blur(80px)",
          animation: "drift-a 18s ease-in-out infinite",
        }}
      />
      <div
        className="absolute rounded-full"
        style={{
          width: "55vw",
          height: "55vw",
          right: "-10vw",
          top: "20vh",
          background: "radial-gradient(circle, rgba(0, 191, 165, 0.22), transparent 65%)",
          filter: "blur(90px)",
          animation: "drift-b 22s ease-in-out infinite",
        }}
      />
      <div
        className="absolute rounded-full"
        style={{
          width: "50vw",
          height: "50vw",
          left: "30vw",
          bottom: "-15vw",
          background: "radial-gradient(circle, rgba(255, 215, 0, 0.12), transparent 65%)",
          filter: "blur(80px)",
          animation: "drift-c 26s ease-in-out infinite",
        }}
      />

      {/* Moving subtle grid (slow vertical scroll) */}
      <div
        className="absolute inset-0 opacity-30"
        style={{
          backgroundImage:
            "linear-gradient(rgba(0, 191, 165, 0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(0, 191, 165, 0.06) 1px, transparent 1px)",
          backgroundSize: "48px 48px",
          animation: "grid-scroll 20s linear infinite",
        }}
      />

      {/* Canvas: stars + particle network + scrolling trading line */}
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />

      <style>{`
        @keyframes drift-a {
          0%, 100% { transform: translate(0, 0) scale(1); }
          50% { transform: translate(40px, 60px) scale(1.1); }
        }
        @keyframes drift-b {
          0%, 100% { transform: translate(0, 0) scale(1); }
          50% { transform: translate(-50px, 40px) scale(1.08); }
        }
        @keyframes drift-c {
          0%, 100% { transform: translate(0, 0) scale(1); }
          50% { transform: translate(60px, -50px) scale(1.05); }
        }
        @keyframes grid-scroll {
          from { background-position: 0 0; }
          to { background-position: 0 48px; }
        }
      `}</style>
    </div>
  );
}
