import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { LineChart, Globe } from "lucide-react";

/**
 * PremiumCircularChart — EXACT pixel-by-pixel replica of the reference image.
 *
 * Layout (top → bottom):
 * 1. Circular chart (~280px diameter, 70% of card width)
 *    - 12px rotating gradient border (teal → blue → purple, 2s/cycle)
 *    - Black inner circle (opacity 0.9)
 *    - Top-center: "LIVE · QUOTEX" (white, 14px)
 *    - Top-left: "M1" (white, 12px)
 *    - Center: 10 candlesticks (8 green / 2 red) with flicker animation
 *    - Bottom-center: "NZD/USD 87.4%" (white, 12px)
 *    - Outer teal glow (opacity 0.2)
 *
 * 2. WIN RATE label (right-aligned)
 *    - "WIN RATE" (white, 14px) + "87.4%" (yellow #FFD700, 24px bold)
 *    - Semi-transparent dark gray bg (opacity 0.3), 8px border-radius
 *    - Pulsing yellow glow
 *
 * 3. Two bottom cards (left/right)
 *    - Left: teal LineChart icon + "87.4%" (32px bold white)
 *    - Right: purple Globe icon + "57" (32px bold white)
 *    - Dark gray bg (opacity 0.8), 12px border-radius
 */
export function PremiumCircularChart() {
  const [flicker, setFlicker] = useState(0);

  // Flicker cycle for candlesticks — simulates live data
  useEffect(() => {
    const int = setInterval(() => setFlicker((v) => v + 1), 800);
    return () => clearInterval(int);
  }, []);

  // 10 candles: 8 green / 2 red — exactly like reference
  const candles = [
    { x: 18, h: 28, up: true },
    { x: 32, h: 36, up: true },
    { x: 46, h: 22, up: false },
    { x: 60, h: 42, up: true },
    { x: 74, h: 30, up: true },
    { x: 88, h: 38, up: true },
    { x: 102, h: 26, up: false },
    { x: 116, h: 44, up: true },
    { x: 130, h: 34, up: true },
    { x: 144, h: 40, up: true },
  ];

  return (
    <div className="flex w-full flex-col items-center gap-5">
      {/* === CIRCULAR CHART — EXACT REPLICA === */}
      <div className="relative" style={{ width: "min(280px, 70vw)", height: "min(280px, 70vw)" }}>
        {/* Outer teal glow (opacity 0.2) */}
        <div
          aria-hidden
          className="absolute -inset-4 rounded-full"
          style={{
            background: "radial-gradient(circle, rgba(0, 191, 165, 0.25), transparent 65%)",
            filter: "blur(20px)",
          }}
        />

        {/* Rotating gradient border (teal → blue → purple, 2s/cycle) */}
        <motion.div
          aria-hidden
          className="absolute inset-0 rounded-full"
          style={{
            background: "conic-gradient(from 0deg, #00BFA5, #2979FF, #9D5BFF, #00BFA5)",
            padding: "12px",
            opacity: 0.85,
            WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)",
            WebkitMaskComposite: "xor",
            maskComposite: "exclude",
          }}
          animate={{ rotate: 360 }}
          transition={{ duration: 2, ease: "linear", repeat: Infinity }}
        />

        {/* Static glow ring overlay (subtle pulsing) */}
        <motion.div
          aria-hidden
          className="absolute inset-0 rounded-full pointer-events-none"
          style={{
            boxShadow: "0 0 32px rgba(0, 191, 165, 0.45), inset 0 0 24px rgba(0, 191, 165, 0.20)",
          }}
          animate={{ opacity: [0.7, 1, 0.7] }}
          transition={{ duration: 2, ease: "easeInOut", repeat: Infinity }}
        />

        {/* Inner black circle (opacity 0.9) */}
        <div
          className="absolute rounded-full overflow-hidden"
          style={{
            inset: "12px",
            background: "rgba(0, 0, 0, 0.92)",
            border: "1px solid rgba(0, 191, 165, 0.25)",
          }}
        >
          {/* Subtle grid pattern inside */}
          <div
            aria-hidden
            className="absolute inset-0 opacity-30"
            style={{
              backgroundImage:
                "radial-gradient(circle at 1px 1px, rgba(255,255,255,0.08) 1px, transparent 0)",
              backgroundSize: "16px 16px",
            }}
          />

          {/* Top-center: "LIVE · QUOTEX" */}
          <div className="absolute left-1/2 top-3 -translate-x-1/2 flex items-center gap-1.5">
            <motion.span
              className="inline-block h-1.5 w-1.5 rounded-full"
              style={{ background: "#00BFA5", boxShadow: "0 0 6px #00BFA5" }}
              animate={{ opacity: [1, 0.3, 1] }}
              transition={{ duration: 1, repeat: Infinity }}
            />
            <span
              className="font-mono text-[10px] font-semibold tracking-wider"
              style={{ color: "#ffffff", letterSpacing: "0.08em" }}
            >
              LIVE · QUOTEX
            </span>
          </div>

          {/* Top-left: "M1" */}
          <div className="absolute left-3 top-9">
            <span
              className="font-mono text-[10px] font-medium"
              style={{ color: "rgba(255,255,255,0.75)" }}
            >
              M1
            </span>
          </div>

          {/* Center: Candlestick chart — 10 candles (8 green / 2 red) */}
          <div className="absolute inset-0 grid place-items-center">
            <svg viewBox="0 0 160 100" className="w-[80%]" preserveAspectRatio="xMidYMid meet">
              <defs>
                <filter id="innerCandleGlowUp" x="-50%" y="-50%" width="200%" height="200%">
                  <feGaussianBlur stdDeviation="1.2" result="b" />
                  <feMerge>
                    <feMergeNode in="b" />
                    <feMergeNode in="SourceGraphic" />
                  </feMerge>
                </filter>
                <filter id="innerCandleGlowDown" x="-50%" y="-50%" width="200%" height="200%">
                  <feGaussianBlur stdDeviation="1" result="b" />
                  <feMerge>
                    <feMergeNode in="b" />
                    <feMergeNode in="SourceGraphic" />
                  </feMerge>
                </filter>
              </defs>

              {/* Baseline */}
              <line x1="10" y1="50" x2="150" y2="50" stroke="rgba(255,255,255,0.08)" strokeDasharray="2 3" />

              {/* 10 Candles — 8 green / 2 red */}
              {candles.map((c, i) => {
                const up = c.up;
                const color = up ? "#00E676" : "#FF3A3A";
                const gradId = up ? `innerUp${i}` : `innerDown${i}`;
                const glowId = up ? "innerCandleGlowUp" : "innerCandleGlowDown";
                const top = 50 - c.h / 2;
                const opacity = 0.85 + ((flicker + i) % 3) * 0.05;
                return (
                  <g key={i}>
                    <defs>
                      <linearGradient id={gradId} x1="0" x2="0" y1="0" y2="1">
                        <stop offset="0" stopColor={up ? "#00E676" : "#FF5252"} />
                        <stop offset="1" stopColor={up ? "#00BFA5" : "#C62828"} />
                      </linearGradient>
                    </defs>
                    {/* Wick */}
                    <line
                      x1={c.x}
                      x2={c.x}
                      y1={top - 6}
                      y2={top + c.h + 6}
                      stroke={color}
                      strokeWidth="1"
                      opacity={opacity * 0.9}
                    />
                    {/* Body */}
                    <rect
                      x={c.x - 4}
                      y={top}
                      width="8"
                      height={c.h}
                      fill={`url(#${gradId})`}
                      rx="1"
                      opacity={opacity}
                      filter={`url(#${glowId})`}
                    />
                    {/* Highlight cap */}
                    <rect
                      x={c.x - 4}
                      y={top}
                      width="8"
                      height={Math.max(1, c.h * 0.3)}
                      fill="rgba(255,255,255,0.35)"
                      rx="1"
                    />
                  </g>
                );
              })}
            </svg>
          </div>

          {/* Bottom-center: "NZD/USD 87.4%" */}
          <div className="absolute bottom-3 left-1/2 -translate-x-1/2">
            <span
              className="font-mono text-[10px] font-medium tracking-wide"
              style={{ color: "rgba(255,255,255,0.85)" }}
            >
              NZD/USD{" "}
              <span style={{ color: "#FFD700", fontWeight: 700, textShadow: "0 0 6px rgba(255,215,0,0.6)" }}>
                87.4%
              </span>
            </span>
          </div>
        </div>
      </div>

      {/* === WIN RATE LABEL — EXACT REPLICA === */}
      <motion.div
        className="inline-flex items-center gap-2 rounded-lg px-3 py-1.5"
        style={{
          background: "rgba(20, 20, 30, 0.55)",
          border: "1px solid rgba(255, 215, 0, 0.30)",
          backdropFilter: "blur(8px)",
          WebkitBackdropFilter: "blur(8px)",
        }}
        animate={{
          boxShadow: [
            "0 0 12px -2px rgba(255, 215, 0, 0.30)",
            "0 0 24px 0px rgba(255, 215, 0, 0.55)",
            "0 0 12px -2px rgba(255, 215, 0, 0.30)",
          ],
        }}
        transition={{ duration: 1, ease: "easeInOut", repeat: Infinity }}
      >
        <span className="text-[11px] font-medium uppercase tracking-wider text-white/90">Win Rate</span>
        <span
          className="font-mono text-lg font-bold tabular-nums"
          style={{ color: "#FFD700", textShadow: "0 0 10px rgba(255, 215, 0, 0.7)" }}
        >
          87.4%
        </span>
      </motion.div>

      {/* === TWO BOTTOM CARDS — EXACT REPLICA === */}
      <div className="grid w-full grid-cols-2 gap-3">
        {/* Left Card — teal LineChart + 87.4% */}
        <div
          className="flex flex-col items-center justify-center gap-2 rounded-xl p-4"
          style={{
            background: "rgba(20, 20, 30, 0.75)",
            border: "1px solid rgba(0, 191, 165, 0.30)",
            backdropFilter: "blur(12px)",
            WebkitBackdropFilter: "blur(12px)",
            boxShadow: "0 4px 20px -8px rgba(0, 0, 0, 0.6), inset 0 1px 0 rgba(255,255,255,0.05)",
          }}
        >
          <div
            className="grid h-9 w-9 place-items-center rounded-lg"
            style={{
              background: "rgba(0, 191, 165, 0.15)",
              border: "1px solid rgba(0, 191, 165, 0.40)",
            }}
          >
            <LineChart
              className="h-4 w-4"
              style={{ color: "#00BFA5", filter: "drop-shadow(0 0 4px rgba(0,191,165,0.7))" }}
            />
          </div>
          <span
            className="text-2xl font-bold tabular-nums"
            style={{ color: "#ffffff", textShadow: "0 0 12px rgba(0, 191, 165, 0.4)" }}
          >
            87.4%
          </span>
          <span className="text-[9px] font-medium uppercase tracking-wider text-white/50">Win Rate</span>
        </div>

        {/* Right Card — purple Globe + 57 */}
        <div
          className="flex flex-col items-center justify-center gap-2 rounded-xl p-4"
          style={{
            background: "rgba(20, 20, 30, 0.75)",
            border: "1px solid rgba(157, 91, 255, 0.30)",
            backdropFilter: "blur(12px)",
            WebkitBackdropFilter: "blur(12px)",
            boxShadow: "0 4px 20px -8px rgba(0, 0, 0, 0.6), inset 0 1px 0 rgba(255,255,255,0.05)",
          }}
        >
          <div
            className="grid h-9 w-9 place-items-center rounded-lg"
            style={{
              background: "rgba(157, 91, 255, 0.15)",
              border: "1px solid rgba(157, 91, 255, 0.40)",
            }}
          >
            <Globe
              className="h-4 w-4"
              style={{ color: "#9D5BFF", filter: "drop-shadow(0 0 4px rgba(157,91,255,0.7))" }}
            />
          </div>
          <span
            className="text-2xl font-bold tabular-nums"
            style={{ color: "#ffffff", textShadow: "0 0 12px rgba(157, 91, 255, 0.4)" }}
          >
            57
          </span>
          <span className="text-[9px] font-medium uppercase tracking-wider text-white/50">OTC Markets</span>
        </div>
      </div>
    </div>
  );
}
